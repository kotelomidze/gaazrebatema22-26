/**
 * converter.html-ის აწყობა: pdf.js, მისი worker და JSZip ჩაშენდება
 * პირდაპირ ფაილში, რომ საიტს გარე ფაილები და საქაღალდეები არ დასჭირდეს.
 */
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = p => fs.readFileSync(path.join(root, p), 'utf8');

const template = read('scripts/converter-template.html');
const parser = read('scripts/converter-parser.js');
const jszip = read('node_modules/jszip/dist/jszip.min.js');
const pdfjs = read('node_modules/pdfjs-dist/build/pdf.min.js');
const worker = fs.readFileSync(path.join(root, 'node_modules/pdfjs-dist/build/pdf.worker.min.js'));

const out = template
  .replace('/*__JSZIP__*/', () => jszip)
  .replace('/*__PDFJS__*/', () => pdfjs)
  .replace('/*__PARSER__*/', () => parser)
  .replace('/*__WORKER_B64__*/', () => worker.toString('base64'));

const target = path.join(root, 'public', 'converter.html');
fs.writeFileSync(target, out);
console.log(`converter.html — ${(out.length / 1024 / 1024).toFixed(1)} MB (ყველაფერი ჩაშენებულია)`);
