/* eslint-disable */
/**
 * PDF -> ტესტის JSON, ბრაუზერში.
 * იგივე ლოგიკა, რაც tools/pdf_to_json.py-ში — ტერმინალის გარეშე.
 */

const OPTION_KEYS = ['ა', 'ბ', 'გ', 'დ'];

const NOISE = [
  'კითხვებზე გადასვლა',
  'დაბრუნება ტექსტის',
  'ყურადღებით გაეცანით ტექსტს',
  'მოცემული ოთხ-ოთხი პასუხიდან',
  'არჩეული პასუხი გადაიტანეთ',
  'პასუხის შესაბამის უჯრედში',
  'ყურადღებით გაეცანით დავალების პირობას',
  'ჩამოაყალიბეთ თქვენი აზრი',
  'მსჯელობა უნდა იყოს ლოგიკურად',
  'სალიტერატურო ენის ნორმები',
  'ნაშრომი შესრულებული უნდა იყოს',
  'გაძნელდება, შეფასებისას',
  'გაითვალისწინეთ',
  'ნაშრომი არ გასწორდება',
  'ნაშრომი, რომლის მოცულობა',
  'იქნება. მოცემული',
];

const QUESTION_RE = /^\((\d+)\)\s*(\d+)\.\s*(.*)$/;
const OPTION_RE = /^([ა-დ])\)\s*(.*)$/;
const PAGENUM_RE = /^\d{1,3}$/;
const INTRO_RE = /ყურადღებით\s+წაიკითხეთ/;
const WORK_RE = /„([^“]+)“/;

const SOURCE_WORDS = [
  'მოთხრობიდან', 'პოემიდან', 'რომანიდან', 'ლექსიდან', 'ნაწარმოებიდან',
  'დრამიდან', 'პიესიდან', 'წიგნიდან', 'ესედან', 'ბალადიდან', 'ნოველიდან',
  'მოთხრობა', 'პოემა', 'რომანი', 'ლექსი', 'ნაწარმოები', 'დრამა', 'პიესა',
  'ბალადა', 'ნოველა', 'ესე',
];

const GUIDELINES = [
  'ჩამოაყალიბეთ თქვენი აზრი ნათლად, მკაფიოდ და დასაბუთებულად, არგუმენტები გაამყარეთ სათანადო მაგალითებით.',
  'მსჯელობა უნდა იყოს ლოგიკურად გამართული და აბზაცებით დანაწევრებული.',
  'შეარჩიეთ შესაბამისი სტილი. დაიცავით სალიტერატურო ენის ნორმები.',
  'ნაშრომი არ გასწორდება, თუ თქვენი მსჯელობა შემოიფარგლება ოთხი-ხუთი წინადადებით.',
  'ნაშრომი, რომლის მოცულობა არ აღემატება 150 სიტყვას, ენობრივი თვალსაზრისით არ შეფასდება.',
];

const PAGE_NAMES = ['პირველი', 'მეორე', 'მესამე', 'მეოთხე', 'მეხუთე', 'მეექვსე'];

const GENITIVE = [
  ['ძის', 'ძე'], ['შვილის', 'შვილი'], ['ელის', 'ელი'], ['ეთის', 'ეთი'],
  ['ურის', 'ური'], ['იანის', 'იანი'], ['ანის', 'ანი'], ['ავას', 'ავა'],
  ['იას', 'ია'], ['უას', 'უა'], ['ონის', 'ონი'], ['ინის', 'ინი'],
];

const KNOWN_WORKS = {
  'ვეფხისტყაოსნის': ['ვეფხისტყაოსანი', 'შოთა რუსთაველი'],
  'დავითიანის': ['დავითიანი', 'დავით გურამიშვილი'],
  'ვისრამიანის': ['ვისრამიანი', ''],
};

const KA2LAT = {
  'ა': 'a', 'ბ': 'b', 'გ': 'g', 'დ': 'd', 'ე': 'e', 'ვ': 'v', 'ზ': 'z', 'თ': 't',
  'ი': 'i', 'კ': 'k', 'ლ': 'l', 'მ': 'm', 'ნ': 'n', 'ო': 'o', 'პ': 'p', 'ჟ': 'zh',
  'რ': 'r', 'ს': 's', 'ტ': 't', 'უ': 'u', 'ფ': 'p', 'ქ': 'k', 'ღ': 'gh', 'ყ': 'q',
  'შ': 'sh', 'ჩ': 'ch', 'ც': 'ts', 'ძ': 'dz', 'წ': 'ts', 'ჭ': 'ch', 'ხ': 'kh',
  'ჯ': 'j', 'ჰ': 'h',
};

function translit(text) {
  let out = '';
  for (const ch of text.toLowerCase()) {
    if (KA2LAT[ch]) out += KA2LAT[ch];
    else if (/[a-z0-9]/.test(ch)) out += ch;
    else if (' -_'.includes(ch)) out += '-';
  }
  return out.replace(/-{2,}/g, '-').replace(/^-|-$/g, '');
}

function nominative(name) {
  const parts = name.split(/\s+/);
  if (!parts.length) return name;
  const last = parts[parts.length - 1];
  for (const [gen, nom] of GENITIVE) {
    if (last.endsWith(gen)) {
      parts[parts.length - 1] = last.slice(0, -gen.length) + nom;
      return parts.join(' ');
    }
  }
  if (last.endsWith('ის') && last.length > 4) {
    parts[parts.length - 1] = last.slice(0, -2) + 'ი';
  }
  return parts.join(' ');
}

/* ---------- PDF -> სტრიქონები ---------- */

/**
 * pdf.js-ის ტექსტის ელემენტებს ვაბრუნებთ სტრიქონებად, ისე როგორც
 * `pdftotext -layout` აკეთებს: y-ით ჯგუფდება, x-ით ლაგდება.
 * ვინახავთ x-საც (აბზაცის შეწევისთვის) და ვერტიკალურ დაშორებას (ცარიელი ხაზი).
 */
async function pdfToPages(file, pdfjsLib) {
  const buf = await file.arrayBuffer();
  const doc = await pdfjsLib.getDocument({ data: buf }).promise;
  const pages = [];

  for (let n = 1; n <= doc.numPages; n++) {
    const page = await doc.getPage(n);
    const content = await page.getTextContent();
    const items = [];
    for (const item of content.items) {
      if (!item.str || !item.str.trim()) continue;
      items.push({ x: item.transform[4], y: item.transform[5], str: item.str, w: item.width || 0 });
    }

    // ერთ სტრიქონად ითვლება ის, რაც 3pt-ის ფარგლებშია — მკაცრი დამრგვალება
    // სიტყვას სხვა სტრიქონზე აგდებდა და ტექსტი ირეოდა
    items.sort((a, b) => b.y - a.y || a.x - b.x);
    const rows = [];
    for (const it of items) {
      const row = rows.length ? rows[rows.length - 1] : null;
      if (row && Math.abs(row.y - it.y) <= 3) row.items.push(it);
      else rows.push({ y: it.y, items: [it] });
    }

    const lines = [];
    for (const row of rows) {
      const sorted = row.items.slice().sort((a, b) => a.x - b.x);
      let text = '';
      let prevEnd = null;
      for (const it of sorted) {
        if (prevEnd !== null && it.x - prevEnd > 2) text += ' ';
        text += it.str;
        prevEnd = it.x + it.w;
      }
      text = text.replace(/\s+/g, ' ').trim();
      if (text) lines.push({ text, x: sorted[0].x, y: row.y });
    }
    pages.push(lines);
  }
  return pages;
}

function isNoise(text) {
  const s = text.trim();
  if (!s) return false;
  if (PAGENUM_RE.test(s)) return true;
  return NOISE.some(n => s.startsWith(n) || s.includes(n));
}

/** ხმაურის მოცილება + შეწევისა და ცარიელი ხაზების აღნიშვნა */
function cleanPages(pages) {
  // ტიპური სტრიქონთაშორისი დაშორება მთელ დოკუმენტზე — ერთ გვერდზე
  // რამდენიმე სტრიქონი რომ დარჩეს, მედიანა არ გამოგვადგება
  const allGaps = [];
  for (const lines of pages) {
    for (let i = 1; i < lines.length; i++) {
      const g = lines[i - 1].y - lines[i].y;
      if (g > 0 && g < 60) allGaps.push(g);
    }
  }
  allGaps.sort((a, b) => a - b);
  const docGap = allGaps.length ? allGaps[Math.floor(allGaps.length / 2)] : 0;

  const out = [];
  for (const lines of pages) {
    const kept = lines.filter(l => !isNoise(l.text));
    if (!kept.length) continue;

    const left = Math.min(...kept.map(l => l.x));
    const marked = kept.map((l, i) => ({
      text: l.text,
      indented: l.x > left + 3,
      blankBefore: i > 0 && docGap > 0 && (kept[i - 1].y - l.y) > docGap * 1.6,
    }));
    out.push(marked);
  }
  return out;
}

/* ---------- ჰედერი ---------- */

function parseHeader(headPages, filename) {
  let title = '', intro = '', bodyStart = 0;
  const first = headPages[0] || [];

  for (let i = 0; i < first.length; i++) {
    const s = first[i].text.trim();
    if (!s) continue;
    if (!title) { title = s; bodyStart = i + 1; continue; }
    if (INTRO_RE.test(s)) {
      intro = s;
      bodyStart = i + 1;
      // შესავალი ორ სტრიქონზეც შეიძლება იყოს — ორწერტილამდე
      for (let j = i + 1; j < first.length && j <= i + 3; j++) {
        if (intro.trim().endsWith(':')) break;
        intro += ' ' + first[j].text.trim();
        bodyStart = j + 1;
      }
    }
    break;
  }

  let source = intro.replace(/^ყურადღებით\s+წაიკითხეთ\s*/, '').replace(/:$/, '').trim();
  const m = WORK_RE.exec(intro);
  let work = m ? m[1] : '';
  let author = '';

  for (const w of SOURCE_WORDS) {
    if (intro.includes(w)) {
      const names = intro.split(w)[0].split(/\s+/).filter(t => /^[\u10A0-\u10FF]/.test(t));
      if (names.length >= 2) author = nominative(names.slice(-2).join(' ').replace(/,$/, ''));
      break;
    }
  }

  if (KNOWN_WORKS[work]) {
    const [w2, a2] = KNOWN_WORKS[work];
    work = w2;
    if (!author) author = a2;
  }

  if (!author) author = authorFromFilename(filename);
  return { title, author, source, work, bodyStart };
}

function authorFromFilename(name) {
  const base = name.replace(/\.pdf$/i, '');
  const words = base.split(/[_\-\s]+/).filter(p => /^[\u10A0-\u10FF]+$/.test(p) && p !== 'გააზრება');
  return words.length ? words[0] : '';
}

/* ---------- ტექსტის სხეული ---------- */

function isVerse(pages) {
  const lines = pages.flat().map(l => l.text.trim()).filter(Boolean);
  if (lines.length < 6) return false;
  const lengths = lines.map(l => l.length).sort((a, b) => a - b);
  const median = lengths[Math.floor(lengths.length / 2)];
  const short = lengths.filter(n => n < 70).length / lengths.length;
  return median < 70 && short >= 0.8;
}

function groupStanzas(pages) {
  const flat = [];
  pages.forEach((lines, pi) => lines.forEach(l => flat.push({ pi, text: l.text })));

  const sizes = [];
  for (const lines of pages) {
    let run = 0;
    lines.forEach((l, i) => {
      if (i > 0 && l.blankBefore) { if (run) sizes.push(run); run = 0; }
      run++;
    });
    if (run) sizes.push(run);
  }

  let size = 4;
  if (sizes.length) {
    const counts = {};
    sizes.forEach(n => counts[n] = (counts[n] || 0) + 1);
    const common = +Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
    if (common >= 2 && common <= 8 && counts[common] >= Math.max(2, Math.floor(sizes.length / 3))) {
      size = common;
    }
  }

  const stanzas = [];
  for (let i = 0; i < flat.length; i += size) {
    const chunk = flat.slice(i, i + size);
    stanzas.push({ pi: chunk[0].pi, lines: chunk.map(c => c.text) });
  }
  return stanzas;
}

function joinParagraphs(lines) {
  const paras = [];
  for (const l of lines) {
    const text = l.text.trim();
    if (!text) continue;
    if (paras.length && !l.indented) paras[paras.length - 1] += ' ' + text;
    else paras.push(text);
  }
  return paras;
}

function buildSections(headPages, bodyStart) {
  const pages = headPages.map((p, i) => (i === 0 ? p.slice(bodyStart) : p));
  const verse = isVerse(pages);

  const sections = pages.map((_, i) => ({
    id: 'part-' + (i + 1),
    title: 'ნაწილი ' + (i + 1),
    subtitle: 'ტექსტის ' + (PAGE_NAMES[i] || i + 1) + ' გვერდი',
  }));

  if (verse) {
    sections.forEach(s => (s.stanzas = []));
    for (const st of groupStanzas(pages)) sections[st.pi].stanzas.push(st.lines);
  } else {
    sections.forEach((s, i) => (s.paragraphs = joinParagraphs(pages[i])));
    for (let i = 0; i + 1 < sections.length; i++) {
      const a = sections[i].paragraphs, b = sections[i + 1].paragraphs;
      if (a && b && a.length && b.length && a[a.length - 1].endsWith('-')) {
        a[a.length - 1] = a[a.length - 1].slice(0, -1) + b.shift();
      }
    }
  }
  return sections.filter(s => (s.stanzas && s.stanzas.length) || (s.paragraphs && s.paragraphs.length));
}

/* ---------- კითხვები ---------- */

function splitHeadAndQuestions(pages) {
  const headPages = [], questionLines = [];
  let hit = false;
  for (const page of pages) {
    if (hit) { questionLines.push(...page); continue; }
    let found = -1;
    for (let i = 0; i < page.length; i++) {
      if (QUESTION_RE.test(page[i].text.trim())) { found = i; break; }
    }
    if (found === -1) headPages.push(page);
    else {
      hit = true;
      if (found) headPages.push(page.slice(0, found));
      questionLines.push(...page.slice(found));
    }
  }
  return { headPages, questionLines };
}

function parseQuestions(lines) {
  const questions = [];
  let current = null, target = null;

  const flush = () => { if (current) { questions.push(current); current = null; } };

  for (const line of lines) {
    const s = line.text.trim();
    if (!s) { target = null; continue; }
    if (line.blankBefore) target = null;

    const mq = QUESTION_RE.exec(s);
    if (mq) {
      flush();
      current = {
        id: +mq[2], number: +mq[2], points: +mq[1],
        text: mq[3].trim(), options: [], correctAnswer: '',
      };
      target = 'text';
      continue;
    }

    const mo = OPTION_RE.exec(s);
    if (mo && current) {
      current.options.push({ key: mo[1], text: mo[2].trim() });
      target = 'option';
      continue;
    }

    if (!current) continue;
    // „იმსჯელეთ, ...“ — თხზულების მითითება, დავალების ფორმულირება არაა
    if (!current.options.length && /^იმსჯელეთ/.test(s)) {
      current.instruction = ((current.instruction || '') + ' ' + s).trim();
      target = 'instruction';
      continue;
    }
    if (target === 'option' && current.options.length) {
      current.options[current.options.length - 1].text += ' ' + s;
    } else if (target === 'instruction') {
      current.instruction = ((current.instruction || '') + ' ' + s).trim();
    } else if (!current.options.length) {
      // კითხვის ტექსტი ხშირად რამდენიმე სტრიქონზეა — ციტატა ცალკე ხაზზე ჩამოდის.
      // ცარიელი ხაზიც კი არ ნიშნავს, რომ კითხვა დამთავრდა: სანამ პასუხები არ დაიწყო,
      // ყველაფერი კითხვის ტექსტია.
      current.text += ' ' + s;
    }
  }
  flush();

  const mcq = questions.filter(q => q.options.length);
  const open = questions.filter(q => !q.options.length);
  let essay = null;
  if (open.length) {
    const q = open[open.length - 1];
    essay = {
      id: q.number,
      points: q.points,
      quote: q.text.trim(),
      instruction: (q.instruction || '').trim() ||
        'იმსჯელეთ, როგორაა წარმოჩენილი ტექსტის მოცემულ მონაკვეთში ეს საკითხი და რამდენად აქტუალურია იგი დღეს.',
      guidelines: GUIDELINES,
      minWords: 150,
    };
  }
  mcq.forEach(q => delete q.instruction);
  return { questions: mcq, essay };
}

/* ---------- მთავარი ---------- */

async function parsePdfFile(file, pdfjsLib) {
  const raw = await pdfToPages(file, pdfjsLib);
  const pages = cleanPages(raw);
  if (!pages.length) throw new Error('ცარიელი PDF');

  const { headPages, questionLines } = splitHeadAndQuestions(pages);
  const { title, author, source, work, bodyStart } = parseHeader(headPages, file.name);
  const sections = buildSections(headPages, bodyStart);
  const { questions, essay } = parseQuestions(questionLines);

  const id = work ? translit(work) : (author ? translit(author.split(' ').pop()) : translit(file.name));

  const test = {
    id: id || 'test',
    order: 999,
    title: title || 'ტექსტი',
    author, work, source,
    sourceFile: file.name,
    sections, questions, essay,
  };

  test.warnings = checkTest(test);
  return test;
}

function checkTest(t) {
  const msgs = [];
  if (!t.sections.length) msgs.push('ტექსტი ვერ ამოიკითხა');
  if (t.questions.length !== 10) msgs.push(`კითხვა ${t.questions.length} (მოსალოდნელი 10)`);
  t.questions.forEach(q => {
    if (q.options.length !== 4) msgs.push(`კითხვა ${q.number} — ${q.options.length} პასუხი`);
  });
  if (!t.essay) msgs.push('თხზულების დავალება ვერ მოიძებნა');
  if (!t.author) msgs.push('ავტორი ვერ ამოიცნო — შეავსე ხელით');
  if (!t.work) msgs.push('ნაწარმოების სათაური ვერ ამოიცნო');
  const verse = t.sections.some(s => s.stanzas);
  if (verse) {
    const sizes = [...new Set(t.sections.flatMap(s => (s.stanzas || []).map(x => x.length)))];
    if (sizes.some(n => n !== 4)) msgs.push(`ლექსი: სტროფების სიგრძე ${sizes.join(', ')} — შეამოწმე`);
  }
  return msgs;
}

window.ExamParser = { parsePdfFile, OPTION_KEYS };
