/**
 * public/tests/index.json-ის ავტომატური აწყობა.
 * გაშვება ხდება ყოველი `npm run dev` და `npm run build` წინ,
 * ამიტომ ახალი ტესტის დამატება = JSON ფაილის ჩაგდება public/tests/-ში.
 */
import fs from 'node:fs';
import path from 'node:path';

const dir = path.join(process.cwd(), 'public');

const items = [];
for (const file of fs.readdirSync(dir).sort()) {
  // ტესტის ფაილები ფესვშია — GitHub-ზე საქაღალდის ატვირთვა რთულია
  if (!file.startsWith('test-') || !file.endsWith('.json')) continue;
  let test;
  try {
    test = JSON.parse(fs.readFileSync(path.join(dir, file), 'utf8'));
  } catch (err) {
    console.warn(`  ! ${file} — გატეხილი JSON, გამოტოვებულია`);
    continue;
  }
  const questions = test.questions || [];
  const answered = questions.filter(q => q.correctAnswer).length;
  items.push({
    id: test.id || path.basename(file, '.json').replace(/^test-/, ''),
    file,
    title: test.title || '',
    author: test.author || '',
    work: test.work || '',
    order: test.order ?? 999,
    source: test.source || '',
    questionCount: questions.length,
    hasEssay: Boolean(test.essay),
    keyComplete: answered === questions.length && answered > 0,
  });
}

items.sort((a, b) => a.order - b.order || a.id.localeCompare(b.id));
fs.writeFileSync(path.join(dir, 'tests.json'), JSON.stringify({ tests: items }, null, 2));

const missing = items.filter(t => !t.keyComplete);
console.log(`tests.json — ${items.length} ტესტი`);
if (missing.length) {
  console.log(`  გასაღები აკლია: ${missing.map(t => t.work || t.id).join(', ')}`);
}
