#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ტესტის PDF -> JSON გადამყვანი.

გამოყენება:
    python3 tools/pdf_to_json.py pdfs/*.pdf
    python3 tools/pdf_to_json.py pdfs/amaqi.pdf --id amaqi

შედეგი იწერება public/tests/<id>.json ფაილებში და ახლდება public/tests/index.json.
სწორი პასუხების ველი (correctAnswer) ცარიელი რჩება — შეავსეთ /answers გვერდიდან.

მოთხოვნა: poppler-utils (pdftotext). შემოწმება: pdftotext -v
"""

import argparse
import json
import os
import re
import subprocess
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
TESTS_DIR = os.path.join(ROOT, "public", "tests")

OPTION_KEYS = ["ა", "ბ", "გ", "დ"]

# ხაზები, რომლებიც PDF-ის ნავიგაციაა და ტექსტს არ ეკუთვნის
NOISE = (
    "კითხვებზე გადასვლა",
    "დაბრუნება ტექსტის",
    "ყურადღებით გაეცანით ტექსტს",
    "მოცემული ოთხ-ოთხი პასუხიდან",
    "არჩეული პასუხი გადაიტანეთ",
    "პასუხის შესაბამის უჯრედში",
    "ყურადღებით გაეცანით დავალების პირობას",
    "ჩამოაყალიბეთ თქვენი აზრი",
    "მსჯელობა უნდა იყოს ლოგიკურად",
    "სალიტერატურო ენის ნორმები",
    "ნაშრომი შესრულებული უნდა იყოს",
    "გაძნელდება, შეფასებისას",
    "გაითვალისწინეთ",
    "ნაშრომი არ გასწორდება",
    "ნაშრომი, რომლის მოცულობა",
    "იქნება. მოცემული",
)

# ნათესაობითი ბრუნვიდან სახელობითში: „ლორთქიფანიძის“ -> „ლორთქიფანიძე“
GENITIVE = [("ძის", "ძე"), ("შვილის", "შვილი"), ("ელის", "ელი"), ("ეთის", "ეთი"),
            ("ურის", "ური"), ("იანის", "იანი"), ("ანის", "ანი"), ("ავას", "ავა"),
            ("იას", "ია"), ("უას", "უა"), ("ონის", "ონი"), ("ინის", "ინი")]


def nominative(name):
    parts = name.split()
    if not parts:
        return name
    last = parts[-1]
    for gen, nom in GENITIVE:
        if last.endswith(gen):
            parts[-1] = last[: -len(gen)] + nom
            return " ".join(parts)
    # ზოგადი წესი: „ყაზბეგის“ -> „ყაზბეგი“
    if last.endswith("ის") and len(last) > 4:
        parts[-1] = last[:-2] + "ი"
    return " ".join(parts)


# ნაწარმოებები, რომელთა სათაურიც ტექსტში ნათესაობითშია
KNOWN_WORKS = {
    "ვეფხისტყაოსნის": ("ვეფხისტყაოსანი", "შოთა რუსთაველი"),
    "დავითიანის": ("დავითიანი", "დავით გურამიშვილი"),
    "ვისრამიანის": ("ვისრამიანი", ""),
}


QUESTION_RE = re.compile(r"^\((\d+)\)\s*(\d+)\.\s*(.*)$")
OPTION_RE = re.compile(r"^([ა-დ])\)\s*(.*)$")
PAGENUM_RE = re.compile(r"^\d{1,3}$")
INTRO_RE = re.compile(r"ყურადღებით\s+წაიკითხეთ")
WORK_RE = re.compile(r"„([^“]+)“")
SOURCE_WORDS = (
    "მოთხრობიდან", "პოემიდან", "რომანიდან", "ლექსიდან", "ნაწარმოებიდან",
    "დრამიდან", "პიესიდან", "წიგნიდან", "ესედან", "ბალადიდან", "ნოველიდან",
    "მოთხრობა", "პოემა", "რომანი", "ლექსი", "ნაწარმოები", "დრამა", "პიესა",
    "ბალადა", "ნოველა", "ესე",
)

GUIDELINES = [
    "ჩამოაყალიბეთ თქვენი აზრი ნათლად, მკაფიოდ და დასაბუთებულად, არგუმენტები გაამყარეთ სათანადო მაგალითებით.",
    "მსჯელობა უნდა იყოს ლოგიკურად გამართული და აბზაცებით დანაწევრებული.",
    "შეარჩიეთ შესაბამისი სტილი. დაიცავით სალიტერატურო ენის ნორმები.",
    "ნაშრომი არ გასწორდება, თუ თქვენი მსჯელობა შემოიფარგლება ოთხი-ხუთი წინადადებით.",
    "ნაშრომი, რომლის მოცულობა არ აღემატება 150 სიტყვას, ენობრივი თვალსაზრისით არ შეფასდება.",
]

PAGE_NAMES = ["პირველი", "მეორე", "მესამე", "მეოთხე", "მეხუთე", "მეექვსე"]


def pdf_to_text(path):
    """pdftotext -layout: ინარჩუნებს აბზაცის შეწევას, რაც აბზაცების აღდგენაში გვეხმარება."""
    try:
        out = subprocess.run(
            ["pdftotext", "-layout", "-enc", "UTF-8", path, "-"],
            capture_output=True, check=True,
        )
    except FileNotFoundError:
        sys.exit("შეცდომა: pdftotext ვერ მოიძებნა. დააინსტალირეთ poppler-utils.")
    except subprocess.CalledProcessError as e:
        sys.exit("შეცდომა PDF-ის წაკითხვისას: %s" % e)
    return out.stdout.decode("utf-8")


def is_noise(line):
    s = line.strip()
    if not s:
        return False
    if PAGENUM_RE.match(s):
        return True
    return any(s.startswith(n) or n in s for n in NOISE)


def clean_pages(raw):
    """PDF-ის გვერდები, ნავიგაციისა და გვერდის ნომრების გარეშე. შეწევა შენარჩუნებულია."""
    pages = []
    for page in raw.split("\f"):
        kept = [ln.rstrip() for ln in page.split("\n") if not is_noise(ln)]
        while kept and not kept[0].strip():
            kept.pop(0)
        while kept and not kept[-1].strip():
            kept.pop()
        if kept:
            pages.append(kept)
    return pages


def join_paragraphs(lines):
    """შეწეული ხაზი = ახალი აბზაცი; შეუწევლელი = წინა აბზაცის გაგრძელება."""
    paras = []
    for ln in lines:
        if not ln.strip():
            continue
        indented = ln[:1].isspace()
        text = " ".join(ln.split())
        if paras and not indented:
            paras[-1] = paras[-1] + " " + text
        else:
            paras.append(text)
    return paras


def split_head_and_questions(pages):
    """ჰედერი+ტექსტი vs. კითხვები — პირველ „(ქულა) ნომერი.“ მარკერამდე."""
    head_pages, question_lines = [], []
    hit = False
    for page in pages:
        if hit:
            question_lines.extend(page)
            continue
        for i, ln in enumerate(page):
            if QUESTION_RE.match(ln.strip()):
                hit = True
                if i:
                    head_pages.append(page[:i])
                question_lines.extend(page[i:])
                break
        else:
            head_pages.append(page)
    return head_pages, question_lines


def parse_header(head_pages, path=""):
    """სათაური („ტექსტი II“), ავტორი, წყარო + ტექსტის საწყისი ხაზი."""
    title, intro = "", ""
    first = head_pages[0] if head_pages else []
    body_start = 0
    for i, ln in enumerate(first):
        s = ln.strip()
        if not s:
            continue
        if not title:
            title = s
            body_start = i + 1
            continue
        if INTRO_RE.search(s):
            intro = s
            body_start = i + 1
            # შესავალი ორ სტრიქონზეც შეიძლება იყოს — ორწერტილამდე
            for j in range(i + 1, min(i + 4, len(first))):
                if intro.rstrip().endswith(":") or not first[j].strip():
                    break
                intro += " " + first[j].strip()
                body_start = j + 1
        break

    source = re.sub(r"^ყურადღებით\s+წაიკითხეთ\s*", "", intro).rstrip(":").strip()
    m = WORK_RE.search(intro)
    work = m.group(1) if m else ""
    author = ""

    for w in SOURCE_WORDS:
        if w in intro:
            names = [t for t in intro.split(w)[0].split() if t and t[0].isalpha()]
            if len(names) >= 2:
                author = nominative(" ".join(names[-2:]).strip(","))
            break

    # სათაური ნათესაობითში: „ვეფხისტყაოსნის“ -> „ვეფხისტყაოსანი“
    if work in KNOWN_WORKS:
        work, known_author = KNOWN_WORKS[work]
        if not author:
            author = known_author

    # ავტორი ვერ მოიძებნა ტექსტში — ფაილის სახელი ხშირად შეიცავს
    if not author:
        author = author_from_filename(path)

    return title, author, source, work, body_start


def author_from_filename(path):
    """„გააზრება__223__რუსთაველი_.pdf“ -> „რუსთაველი“"""
    base = os.path.splitext(os.path.basename(path))[0]
    parts = [p for p in re.split(r"[_\-\s]+", base) if p]
    words = [p for p in parts if re.match(r"^[\u10A0-\u10FF]+$", p) and p != "გააზრება"]
    return words[0] if words else ""


def is_verse(pages):
    """
    ლექსი თუ პროზა. შეწევას ვერ ვენდობით — გვერდის გადატანისას იკარგება.
    საიმედო ნიშანი სტრიქონის სიგრძეა: ლექსი 25-50 სიმბოლო, პროზა 100-120
    (რადგან პროზაში სტრიქონი გვერდის სიგანეზე იჭიმება).
    """
    lines = [ln.strip() for page in pages for ln in page if ln.strip()]
    if len(lines) < 6:
        return False
    lengths = sorted(len(ln) for ln in lines)
    median = lengths[len(lengths) // 2]
    short = sum(1 for n in lengths if n < 70) / len(lengths)
    return median < 70 and short >= 0.8


def group_stanzas(pages):
    """
    სტროფებად დაყოფა. აბრუნებს (გვერდის_ინდექსი, [სტრიქონები]) წყვილებს.
    სტროფის სიგრძეს ცარიელი ხაზებით ვადგენთ; თუ არ არის — ოთხ-ოთხი (შაირი).
    დაყოფა გლობალურია, ამიტომ გვერდზე გადატანილი სტროფი არ იშლება.
    """
    flat = [(pi, " ".join(ln.split()))
            for pi, page in enumerate(pages) for ln in page if ln.strip()]

    # ცარიელი ხაზებით გამოყოფილი ჯგუფების ყველაზე ხშირი სიგრძე
    sizes = []
    for page in pages:
        run = 0
        for ln in list(page) + [""]:
            if ln.strip():
                run += 1
            else:
                if run:
                    sizes.append(run)
                run = 0

    size = 4
    if sizes:
        common = max(set(sizes), key=sizes.count)
        if 2 <= common <= 8 and sizes.count(common) >= max(2, len(sizes) // 3):
            size = common

    stanzas = []
    for i in range(0, len(flat), size):
        chunk = flat[i:i + size]
        stanzas.append((chunk[0][0], [t for _, t in chunk]))
    return stanzas


def build_sections(head_pages, body_start):
    pages = [page[body_start:] if idx == 0 else page for idx, page in enumerate(head_pages)]
    verse = is_verse(pages)

    sections = []
    for idx in range(len(pages)):
        name = PAGE_NAMES[idx] if idx < len(PAGE_NAMES) else str(idx + 1)
        sections.append({
            "id": "part-%d" % (idx + 1),
            "title": "ნაწილი %d" % (idx + 1),
            "subtitle": "ტექსტის %s გვერდი" % name,
        })

    if verse:
        for sec in sections:
            sec["stanzas"] = []
        for pi, lines in group_stanzas(pages):
            sections[pi]["stanzas"].append(lines)
    else:
        for idx, sec in enumerate(sections):
            sec["paragraphs"] = join_paragraphs(pages[idx])
        # „...იანეს ღო-“ / „ნეც შემოიმატა...“ — გვერდზე გადატანილი სიტყვა
        for a, b in zip(sections, sections[1:]):
            pa, pb = a.get("paragraphs"), b.get("paragraphs")
            if pa and pb and pa[-1].endswith("-"):
                pa[-1] = pa[-1][:-1] + pb.pop(0)

    return [s for s in sections if s.get("stanzas") or s.get("paragraphs")]


def parse_questions(lines):
    questions, essay = [], None
    current = None      # მიმდინარე კითხვა
    target = None       # სად მიემატოს გადატანილი ხაზი: "text" | "option"

    def flush():
        nonlocal current
        if current:
            questions.append(current)
            current = None

    i = 0
    while i < len(lines):
        s = lines[i].strip()
        i += 1
        if not s:
            target = None
            continue

        mq = QUESTION_RE.match(s)
        if mq:
            flush()
            current = {
                "id": int(mq.group(2)),
                "number": int(mq.group(2)),
                "points": int(mq.group(1)),
                "text": mq.group(3).strip(),
                "options": [],
                "correctAnswer": "",
            }
            target = "text"
            continue

        mo = OPTION_RE.match(s)
        if mo and current is not None:
            current["options"].append({"key": mo.group(1), "text": mo.group(2).strip()})
            target = "option"
            continue

        if current is not None:
            # „იმსჯელეთ, ...“ — თხზულების მითითება, დავალების ფორმულირება არაა
            if not current["options"] and s.startswith("იმსჯელეთ"):
                current.setdefault("instruction", "")
                current["instruction"] = (current["instruction"] + " " + s).strip()
                target = None
                continue
            if target == "option" and current["options"]:
                current["options"][-1]["text"] += " " + s
            elif target == "text":
                current["text"] += " " + s
            elif not current["options"] and target is None:
                current.setdefault("instruction", "")
                current["instruction"] = (current["instruction"] + " " + s).strip()
            else:
                # კითხვის შემდეგ დამატებითი ინსტრუქცია (ჩვეულებრივ თხზულებისთვის)
                current.setdefault("instruction", "")
                current["instruction"] = (current["instruction"] + " " + s).strip()
    flush()

    mcq = [q for q in questions if q["options"]]
    open_q = [q for q in questions if not q["options"]]
    if open_q:
        q = open_q[-1]
        essay = {
            "id": q["number"],
            "points": q["points"],
            "quote": q["text"].strip(),
            "instruction": q.get("instruction", "").strip() or
                           "იმსჯელეთ, როგორაა წარმოჩენილი ტექსტის მოცემულ მონაკვეთში ეს საკითხი და რამდენად აქტუალურია იგი დღეს.",
            "guidelines": GUIDELINES,
            "minWords": 150,
        }
    for q in mcq:
        q.pop("instruction", None)
    return mcq, essay


KA2LAT = {
    "ა": "a", "ბ": "b", "გ": "g", "დ": "d", "ე": "e", "ვ": "v", "ზ": "z", "თ": "t",
    "ი": "i", "კ": "k", "ლ": "l", "მ": "m", "ნ": "n", "ო": "o", "პ": "p", "ჟ": "zh",
    "რ": "r", "ს": "s", "ტ": "t", "უ": "u", "ფ": "p", "ქ": "k", "ღ": "gh", "ყ": "q",
    "შ": "sh", "ჩ": "ch", "ც": "ts", "ძ": "dz", "წ": "ts", "ჭ": "ch", "ხ": "kh",
    "ჯ": "j", "ჰ": "h",
}


def translit(text):
    """ქართული -> ლათინური, ფაილის სახელისთვის."""
    out = []
    for ch in text.lower():
        if ch in KA2LAT:
            out.append(KA2LAT[ch])
        elif ch.isalnum():
            out.append(ch)
        elif ch in " -_":
            out.append("-")
    slug = re.sub(r"-{2,}", "-", "".join(out)).strip("-")
    return slug


def slugify(name):
    base = os.path.splitext(os.path.basename(name))[0]
    base = unicodedata.normalize("NFKC", base)
    base = re.sub(r"[\s_]+", "-", base.strip())
    base = re.sub(r"[^\w\-\u10A0-\u10FF]", "", base)
    return re.sub(r"-{2,}", "-", base).strip("-").lower() or "test"


def make_id(work, author, path):
    """id ნაწარმოების სათაურიდან: „ამაყი“ -> amaqi"""
    if work:
        slug = translit(work)
        if slug:
            return slug
    if author:
        slug = translit(author.split()[-1])
        if slug:
            return slug
    return slugify(path)


def parse_pdf(path, test_id=None):
    pages = clean_pages(pdf_to_text(path))
    if not pages:
        raise ValueError("ცარიელი PDF")
    head_pages, qlines = split_head_and_questions(pages)
    title, author, source, work, body_start = parse_header(head_pages, path)
    sections = build_sections(head_pages, body_start)
    questions, essay = parse_questions(qlines)
    return {
        "id": test_id or make_id(work, author, path),
        "order": 999,
        "title": title or "ტექსტი",
        "author": author,
        "work": work,
        "source": source,
        "sourceFile": os.path.basename(path),
        "sections": sections,
        "questions": questions,
        "essay": essay,
    }


def warn(test):
    msgs = []
    if not test["sections"]:
        msgs.append("ტექსტი ვერ ამოიკითხა")
    if len(test["questions"]) != 10:
        msgs.append("კითხვა: %d (მოსალოდნელი 10)" % len(test["questions"]))
    for q in test["questions"]:
        if len(q["options"]) != 4:
            msgs.append("კითხვა %s — %d პასუხი" % (q["number"], len(q["options"])))
    if not test["essay"]:
        msgs.append("თხზულების დავალება ვერ მოიძებნა")
    if not test["author"]:
        msgs.append("ავტორი ვერ ამოიცნო — შეავსეთ ხელით")
    if not test.get("work"):
        msgs.append("ნაწარმოების სათაური ვერ ამოიცნო")
    verse = any("stanzas" in s for s in test["sections"])
    if verse:
        sizes = {len(st) for s in test["sections"] for st in s.get("stanzas", [])}
        if sizes - {4}:
            msgs.append("ლექსი: სტროფების სიგრძე %s — შეამოწმეთ დაყოფა" % sorted(sizes))
    return msgs


def rebuild_index():
    """tests/index.json — სია. რიგითობა: ტესტის "order" ველი, შემდეგ id."""
    items = []
    for fn in sorted(os.listdir(TESTS_DIR)):
        if not fn.endswith(".json") or fn == "index.json":
            continue
        with open(os.path.join(TESTS_DIR, fn), encoding="utf-8") as f:
            t = json.load(f)
        answered = sum(1 for q in t.get("questions", []) if q.get("correctAnswer"))
        items.append({
            "id": t["id"],
            "file": fn,
            "title": t.get("title", ""),
            "author": t.get("author", ""),
            "work": t.get("work", ""),
            "order": t.get("order", 999),
            "source": t.get("source", ""),
            "questionCount": len(t.get("questions", [])),
            "hasEssay": bool(t.get("essay")),
            "keyComplete": answered == len(t.get("questions", [])) and answered > 0,
        })
    items.sort(key=lambda x: (x["order"], x["id"]))
    path = os.path.join(TESTS_DIR, "index.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"tests": items}, f, ensure_ascii=False, indent=2)
    return len(items)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pdfs", nargs="+")
    ap.add_argument("--id", help="ერთი PDF-ის შემთხვევაში — სასურველი id")
    ap.add_argument("--out", default=TESTS_DIR)
    args = ap.parse_args()

    os.makedirs(args.out, exist_ok=True)
    for path in args.pdfs:
        try:
            test = parse_pdf(path, args.id if len(args.pdfs) == 1 else None)
        except Exception as e:
            print("✗ %s — %s" % (os.path.basename(path), e))
            continue

        out_path = os.path.join(args.out, test["id"] + ".json")
        if os.path.exists(out_path):  # არსებული პასუხების გასაღები არ დაიკარგოს
            with open(out_path, encoding="utf-8") as f:
                old = {q["number"]: q.get("correctAnswer", "") for q in json.load(f).get("questions", [])}
            for q in test["questions"]:
                q["correctAnswer"] = old.get(q["number"], "")

        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(test, f, ensure_ascii=False, indent=2)

        problems = warn(test)
        mark = "!" if problems else "✓"
        print("%s %s -> tests/%s.json  (%d კითხვა)" % (mark, os.path.basename(path), test["id"], len(test["questions"])))
        for m in problems:
            print("    · " + m)

    print("\nindex.json განახლდა — %d ტესტი" % rebuild_index())


if __name__ == "__main__":
    main()
