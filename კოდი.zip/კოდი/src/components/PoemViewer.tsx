import React, { useState } from 'react';
import { useExam } from '../data/examSource';
import { BookOpen, ZoomIn, ZoomOut, ArrowRight, Layers } from 'lucide-react';

interface PoemViewerProps {
  onJumpToQuestions?: () => void;
  isCompact?: boolean;
  highlightedStanza?: number | null;
}

export const PoemViewer: React.FC<PoemViewerProps> = ({
  onJumpToQuestions,
  isCompact = false,
}) => {
  const POEM_DATA = useExam();
  const [fontSize, setFontSize] = useState<number>(15);
  const [activeSection, setActiveSection] = useState<string>('all');

  const filteredSections = activeSection === 'all'
    ? POEM_DATA.sections
    : POEM_DATA.sections.filter(s => s.id === activeSection);

  // გვერდების ნომრები რომაულად — რამდენი ნაწილიც აქვს ტესტს, იმდენი ღილაკი
  const ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI'];

  // სტროფის გლობალური ნომერი, სექციების ცვლადი სიგრძის გათვალისწინებით
  const stanzaOffsets: Record<string, number> = {};
  let running = 0;
  POEM_DATA.sections.forEach(sec => {
    stanzaOffsets[sec.id] = running;
    running += (sec.stanzas?.length ?? sec.paragraphs?.length ?? 0);
  });

  return (
    <div className="bg-white rounded-2xl border border-amber-200/70 shadow-sm flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50/50 border-b border-amber-200/60 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-amber-600 text-white rounded-xl shadow-sm">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-slate-800 text-base leading-tight">
              {POEM_DATA.title} — {POEM_DATA.author}
            </h3>
            <p className="text-xs text-amber-900/80 font-medium">
              {POEM_DATA.source}
            </p>
          </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-2">
          {/* Section Filter Pills */}
          <div className="flex items-center bg-white/90 p-1 rounded-lg border border-amber-200 text-xs font-medium">
            <button
              onClick={() => setActiveSection('all')}
              className={`px-2 py-1 rounded transition-colors ${
                activeSection === 'all'
                  ? 'bg-amber-600 text-white font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              სრული
            </button>
            {POEM_DATA.sections.map((sec, i) => (
              <button
                key={sec.id}
                onClick={() => setActiveSection(sec.id)}
                className={`px-2 py-1 rounded transition-colors ${
                  activeSection === sec.id
                    ? 'bg-amber-600 text-white font-semibold shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {ROMAN[i] || i + 1} გვერდი
              </button>
            ))}
          </div>

          {/* Font Controls */}
          <div className="flex items-center gap-1 bg-white/90 px-1 py-1 rounded-lg border border-amber-200 text-slate-600">
            <button
              onClick={() => setFontSize(s => Math.max(13, s - 1))}
              className="p-1 hover:bg-amber-100 rounded text-slate-700"
              title="შრიფტის დაპატარავება"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="text-[11px] font-mono font-medium px-1 text-slate-500">{fontSize}px</span>
            <button
              onClick={() => setFontSize(s => Math.min(22, s + 1))}
              className="p-1 hover:bg-amber-100 rounded text-slate-700"
              title="შრიფტის გადიდება"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Poem Body */}
      <div className="p-4 md:p-6 overflow-y-auto flex-1 space-y-6 bg-[#fcfbfa]">
        {filteredSections.map((section) => (
          <div key={section.id} className="space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-amber-100">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-amber-100/90 text-amber-800">
                <Layers className="w-3 h-3" />
                {section.title}
              </span>
              {section.subtitle && (
                <span className="text-xs text-slate-500 font-medium">
                  {section.subtitle}
                </span>
              )}
            </div>

            <div className="grid grid-cols-1 gap-4 font-serif">
              {(section.stanzas ?? (section.paragraphs ?? []).map(p => [p])).map((block, stIdx) => {
                const globalStanzaNumber = stanzaOffsets[section.id] + stIdx + 1;
                return (
                  <div
                    key={stIdx}
                    className="p-3.5 rounded-xl bg-white border border-amber-100/80 shadow-xs hover:border-amber-300 transition-all group"
                  >
                    <div className="flex items-start gap-3">
                      <span className="text-[11px] font-mono font-bold text-amber-700 bg-amber-50 rounded-md w-5 h-5 flex items-center justify-center shrink-0 mt-0.5">
                        {globalStanzaNumber}
                      </span>
                      <div
                        className="space-y-1 text-slate-800 font-normal leading-relaxed"
                        style={{ fontSize: `${fontSize}px` }}
                      >
                        {block.map((line, lIdx) => (
                          <p key={lIdx} className="tracking-normal select-text">
                            {line}
                          </p>
                        ))}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Quick Jump Action if requested */}
      {onJumpToQuestions && (
        <div className="p-3 bg-amber-50/60 border-t border-amber-100 flex justify-end">
          <button
            onClick={onJumpToQuestions}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-900 bg-amber-200/80 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer"
          >
            კითხვებზე გადასვლა (2-11)
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};
