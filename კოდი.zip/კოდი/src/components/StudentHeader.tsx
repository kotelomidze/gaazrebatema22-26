import React, { useState, useEffect } from 'react';
import { StudentInfo } from '../types';
import { useExam } from '../data/examSource';
import {
  User,
  Clock,
  BookOpen,
  Send,
  Settings,
  Layers,
  FileText,
  CheckCircle2
} from 'lucide-react';

interface StudentHeaderProps {
  student: StudentInfo;
  activeTab: 'all' | 'comprehension' | 'essay';
  onSelectTab: (tab: 'all' | 'comprehension' | 'essay') => void;
  answeredCount: number;
  essayWordCount: number;
  onOpenPoemModal: () => void;
  onSubmitClick: () => void;
  onOpenTeacherConfig: () => void;
}

export const StudentHeader: React.FC<StudentHeaderProps> = ({
  student,
  activeTab,
  onSelectTab,
  answeredCount,
  essayWordCount,
  onOpenPoemModal,
  onSubmitClick,
  onOpenTeacherConfig,
}) => {
  const [elapsedSeconds, setElapsedSeconds] = useState<number>(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds(s => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const totalQuestions = useExam().questions.length;

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5">
        
        {/* Upper Row: Student Info, Timer, Actions */}
        <div className="flex items-center justify-between gap-3">
          
          {/* Student Badge */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
              {student.firstName[0]}{student.lastName[0]}
            </div>
            <div>
              <div className="text-xs sm:text-sm font-bold text-slate-900 leading-tight">
                {student.firstName} {student.lastName}
              </div>
              <div className="text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
                {student.className ? (
                  <span>{student.className}</span>
                ) : (
                  <span>საგამოცდო ტესტი</span>
                )}
                <span>•</span>
                <span className="inline-flex items-center gap-0.5 text-indigo-600 font-mono font-semibold">
                  <Clock className="w-3 h-3" />
                  {formatTimer(elapsedSeconds)}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2">
            
            {/* Quick Poem Button */}
            <button
              onClick={onOpenPoemModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 text-xs font-semibold transition-colors cursor-pointer"
              title="ტექსტის სრული ნახვა"
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-700" />
              <span className="hidden sm:inline">ტექსტი</span>
            </button>

            {/* Teacher Config Gear */}
            <button
              onClick={onOpenTeacherConfig}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="მასწავლებლის პარამეტრები & Apps Script"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Submit Button */}
            <button
              onClick={onSubmitClick}
              className="inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-bold shadow-xs hover:shadow-sm transition-all cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>გაგზავნა</span>
            </button>
          </div>
        </div>

        {/* Lower Row: Tab Navigation & Real-time Progress */}
        <div className="mt-2.5 pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
          
          {/* Navigation Tabs */}
          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold">
            <button
              onClick={() => onSelectTab('all')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'all'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>ორივე კომპონენტი</span>
            </button>

            <button
              onClick={() => onSelectTab('comprehension')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'comprehension'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>I. გააზრება</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                answeredCount === totalQuestions
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-indigo-100 text-indigo-800'
              }`}>
                {answeredCount}/{totalQuestions}
              </span>
            </button>

            <button
              onClick={() => onSelectTab('essay')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1.5 ${
                activeTab === 'essay'
                  ? 'bg-white text-purple-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>II. თხზულება</span>
              {essayWordCount > 0 && (
                <span className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                  essayWordCount >= 150
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-900'
                }`}>
                  {essayWordCount} სიტყვა
                </span>
              )}
            </button>
          </div>

          {/* Quick Progress Mini Status */}
          <div className="hidden md:flex items-center gap-3 text-xs text-slate-500 font-medium">
            <span className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${answeredCount > 0 ? 'bg-indigo-600' : 'bg-slate-300'}`} />
              გააზრება: <strong>{answeredCount}/{totalQuestions}</strong>
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full ${essayWordCount >= 150 ? 'bg-emerald-500' : essayWordCount > 0 ? 'bg-amber-500' : 'bg-slate-300'}`} />
              თხზულება: <strong>{essayWordCount} სიტყვა</strong>
            </span>
          </div>

        </div>

      </div>
    </header>
  );
};
