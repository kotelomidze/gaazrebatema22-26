import React, { useState } from 'react';
import { StudentInfo, TestSummary } from '../types';
import { testLabel } from '../data/examSource';
import { GraduationCap, BookOpen, PenTool, CheckCircle2, ArrowRight, ShieldCheck, Clock, Search } from 'lucide-react';

interface StartScreenProps {
  onStartExam: (student: StudentInfo) => void;
  tests: TestSummary[];
  selectedTestId: string;
  onSelectTest: (id: string) => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({
  onStartExam,
  tests,
  selectedTestId,
  onSelectTest,
}) => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [error, setError] = useState('');
  const [query, setQuery] = useState('');

  const selectedTest = tests.find(t => t.id === selectedTestId);

  // ძებნა ავტორზე, ნაწარმოებზე და აღწერაზე — სიტყვის ნაწილიც კმარა
  const needle = query.trim().toLowerCase();
  const filteredTests = needle
    ? tests.filter(t =>
        [t.author, t.work, t.title, t.source].some(v => (v || '').toLowerCase().includes(needle))
      )
    : tests;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTestId) {
      setError('გთხოვთ, აირჩიოთ საგამოცდო ტექსტი');
      return;
    }
    if (!firstName.trim() || !lastName.trim()) {
      setError('გთხოვთ, აუცილებლად მიუთითოთ სახელი და გვარი');
      return;
    }
    setError('');
    onStartExam({
      firstName: firstName.trim(),
      lastName: lastName.trim(),
      startedAt: new Date().toISOString(),
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-indigo-50/20 to-slate-100 flex items-center justify-center p-4 md:p-6">
      <div className="w-full max-w-2xl bg-white rounded-3xl shadow-xl border border-slate-200/80 overflow-hidden">
        
        {/* Banner Header */}
        <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white p-6 md:p-8 text-center relative overflow-hidden">
          <div className="absolute -top-12 -right-12 w-48 h-48 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none" />
          <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-purple-500/20 rounded-full blur-2xl pointer-events-none" />

          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-xs font-semibold mb-3">
            <GraduationCap className="w-4 h-4 text-amber-300" />
            საგამოცდო პლატფორმა
          </div>

          <h1 className="text-xl md:text-2xl font-extrabold tracking-tight">
            ქართული ენა და ლიტერატურა
          </h1>
          <p className="text-sm text-indigo-200 mt-1 font-medium">
            {selectedTest ? `${selectedTest.title}: ${testLabel(selectedTest)}` : 'აირჩიეთ საგამოცდო ტექსტი'}
          </p>
        </div>

        {/* Form Container */}
        <div className="p-6 md:p-8 space-y-6">
          
          {/* Exam Structure Preview Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div className="p-4 rounded-2xl bg-indigo-50/60 border border-indigo-100 flex items-start gap-3">
              <div className="p-2 rounded-xl bg-indigo-600 text-white shrink-0 mt-0.5">
                <BookOpen className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-indigo-700">
                  კომპონენტი I
                </div>
                <div className="text-sm font-bold text-slate-800">
                  ტექსტის გააზრება
                </div>
                <div className="text-xs text-slate-500 mt-0.5">
                  {selectedTest ? selectedTest.questionCount : 10} დახურული კითხვა ({selectedTest ? selectedTest.questionCount : 10} ქულა)
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-purple-50/60 border border-purple-100 flex items-start gap-3">
              <div className="p-2 rounded-xl bg-purple-600 text-white shrink-0 mt-0.5">
                <PenTool className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-bold uppercase tracking-wider text-purple-700">
                  კომპონენტი II
                </div>
                <div className="text-sm font-bold text-slate-800">
                  თხზულება
                </div>
                <div className="text-xs text-slate-500 mt-0.5">
                  დავალება 12 (34 ქულა)
                </div>
              </div>
            </div>
          </div>

          {/* Student Identification Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="border-t border-slate-100 pt-4">
              <h2 className="text-sm font-bold text-slate-800 mb-1">
                საგამოცდო ტექსტი
              </h2>
              <p className="text-xs text-slate-500 mb-4">
                მოძებნეთ და აირჩიეთ ტექსტი, რომელზეც ტესტს გაივლით.
              </p>
              <div className="relative mb-2">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="მოძებნეთ ავტორი ან ნაწარმოები"
                  className="w-full pl-10 pr-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 outline-hidden transition-all bg-slate-50/50"
                />
              </div>

              {/* შედეგები ჩნდება მხოლოდ ძებნისას */}
              {query.trim() && (
                <div className="max-h-64 overflow-y-auto rounded-xl border border-slate-200 divide-y divide-slate-100">
                  {filteredTests.length === 0 && (
                    <div className="px-3.5 py-3 text-xs text-slate-500">ვერაფერი მოიძებნა</div>
                  )}
                  {filteredTests.map(t => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => {
                        onSelectTest(t.id);
                        setQuery('');
                      }}
                      className={`w-full text-left px-3.5 py-2.5 text-sm transition-colors cursor-pointer flex items-center gap-2 ${
                        selectedTestId === t.id
                          ? 'bg-indigo-50 text-indigo-900 font-semibold'
                          : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      {selectedTestId === t.id && <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />}
                      <span>{testLabel(t)}</span>
                    </button>
                  ))}
                </div>
              )}

              {/* არჩეული ტექსტი */}
              {!query.trim() && selectedTest && (
                <div className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-indigo-50 border border-indigo-100 text-sm text-indigo-900 font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                  <span className="flex-1">{testLabel(selectedTest)}</span>
                  <button
                    type="button"
                    onClick={() => onSelectTest('')}
                    className="text-xs text-indigo-600 hover:text-indigo-900 font-semibold underline underline-offset-2 cursor-pointer"
                  >
                    შეცვლა
                  </button>
                </div>
              )}

              {!query.trim() && !selectedTest && (
                <p className="text-xs text-slate-400">
                  {tests.length === 0
                    ? 'ტესტები ვერ ჩაიტვირთა'
                    : `ჩაწერეთ ავტორის ან ნაწარმოების სახელი — სულ ${tests.length} ტექსტი`}
                </p>
              )}
            </div>

            <div className="border-t border-slate-100 pt-4">
              <h2 className="text-sm font-bold text-slate-800 mb-1">
                მოსწავლის მონაცემები
              </h2>
              <p className="text-xs text-slate-500 mb-4">
                ტესტის დაწყებამდე გთხოვთ შეიყვანოთ თქვენი სახელი და გვარი.
              </p>
            </div>

            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold rounded-xl flex items-center gap-2">
                <span>⚠️ {error}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  სახელი <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 outline-hidden transition-all bg-slate-50/50"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  გვარი <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 outline-hidden transition-all bg-slate-50/50"
                  required
                />
              </div>
            </div>

            {/* Start Button */}
            <button
              type="submit"
              className="w-full py-3.5 px-6 rounded-xl bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white font-bold text-sm shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer mt-2"
            >
              ტესტის დაწყება
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

        </div>

      </div>
    </div>
  );
};
