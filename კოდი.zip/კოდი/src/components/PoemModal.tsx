import React from 'react';
import { PoemViewer } from './PoemViewer';
import { useExam, testLabel } from '../data/examSource';
import { X } from 'lucide-react';

interface PoemModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PoemModal: React.FC<PoemModalProps> = ({ isOpen, onClose }) => {
  const exam = useExam();
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <div className="p-4 bg-amber-50 border-b border-amber-200/80 flex items-center justify-between">
          <div className="text-sm font-bold text-amber-950">
            საგამოცდო ტექსტი: {testLabel(exam)}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-amber-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-hidden p-2 bg-slate-50">
          <PoemViewer onJumpToQuestions={onClose} />
        </div>
      </div>
    </div>
  );
};
