import React, { useEffect } from 'react';
import { PoemViewer } from './PoemViewer';
import { useExam, testLabel } from '../data/examSource';
import { X } from 'lucide-react';

interface PoemModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PoemModal: React.FC<PoemModalProps> = ({ isOpen, onClose }) => {
  const exam = useExam();

  // Esc-ით დახურვა
  useEffect(() => {
    if (!isOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-2 sm:p-6"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl h-[92vh] sm:h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-3 sm:p-4 bg-amber-50 border-b border-amber-200/80 flex items-center justify-between gap-2">
          <div className="text-xs sm:text-sm font-bold text-amber-950 min-w-0 truncate">
            საგამოცდო ტექსტი: {testLabel(exam)}
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-lg hover:bg-amber-100 transition-colors cursor-pointer shrink-0"
            aria-label="დახურვა"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="flex-1 overflow-hidden p-1.5 sm:p-2 bg-slate-50">
          <PoemViewer onJumpToQuestions={onClose} />
        </div>
      </div>
    </div>
  );
};
