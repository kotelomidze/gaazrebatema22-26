import React, { useState } from 'react';
import { GOOGLE_APPS_SCRIPT_SAMPLE, DEFAULT_TEACHER_EMAIL } from '../data/examData';
import { X, Copy, Check, ExternalLink, Mail, ShieldAlert, Code2, Sparkles, Send } from 'lucide-react';

interface TeacherConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  webhookUrl: string;
  onSaveWebhookUrl: (url: string) => void;
  teacherEmail: string;
  onSaveTeacherEmail: (email: string) => void;
}

export const TeacherConfigModal: React.FC<TeacherConfigModalProps> = ({
  isOpen,
  onClose,
  webhookUrl,
  onSaveWebhookUrl,
  teacherEmail,
  onSaveTeacherEmail,
}) => {
  const [copied, setCopied] = useState(false);
  const [tempUrl, setTempUrl] = useState(webhookUrl);
  const [tempEmail, setTempEmail] = useState(teacherEmail);
  const [activeTab, setActiveTab] = useState<'script' | 'settings'>('script');
  const [saveSuccess, setSaveSuccess] = useState(false);

  if (!isOpen) return null;

  const handleCopyCode = () => {
    // Inject current email into sample code
    const personalizedCode = GOOGLE_APPS_SCRIPT_SAMPLE.replace(
      DEFAULT_TEACHER_EMAIL,
      tempEmail || DEFAULT_TEACHER_EMAIL
    );
    navigator.clipboard.writeText(personalizedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveWebhookUrl(tempUrl.trim());
    onSaveTeacherEmail(tempEmail.trim() || DEFAULT_TEACHER_EMAIL);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="p-5 md:p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-600 rounded-xl text-white">
              <Code2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base md:text-lg font-bold">
                Google Apps Script & მასწავლებლის პარამეტრები
              </h2>
              <p className="text-xs text-slate-300">
                ტესტის შედეგების ავტომატური მიღება იმეილზე
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-3 gap-2">
          <button
            onClick={() => setActiveTab('script')}
            className={`pb-3 px-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              activeTab === 'script'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            📋 1. Apps Script კოდი და ინსტრუქცია
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`pb-3 px-3 text-xs font-bold transition-all border-b-2 cursor-pointer ${
              activeTab === 'settings'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            ⚙️ 2. Webhook URL & იმეილი
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          {activeTab === 'script' ? (
            <div className="space-y-4">
              {/* Step-by-step Instructions */}
              <div className="bg-indigo-50/70 border border-indigo-100 rounded-2xl p-4 text-xs text-indigo-950 space-y-2">
                <div className="font-bold flex items-center gap-1.5 text-indigo-900">
                  <Sparkles className="w-4 h-4 text-indigo-600" />
                  როგორ გავმართოთ 1 წუთში (Google Apps Script):
                </div>
                <ol className="list-decimal list-inside space-y-1.5 pl-1 text-slate-700">
                  <li>
                    გახსენით <a href="https://script.google.com/home/start" target="_blank" rel="noreferrer" className="font-bold text-indigo-600 underline">script.google.com</a> და დააჭირეთ <strong>„New project“ (ახალი პროექტი)</strong>.
                  </li>
                  <li>
                    დააკოპირეთ ქვემოთ მოცემული კოდი და ჩასვით რედაქტორში (წაშალეთ იქ არსებული ცარიელი ფუნქცია).
                  </li>
                  <li>
                    დააჭირეთ ლურჯ ღილაკს <strong>Deploy → New deployment</strong>.
                  </li>
                  <li>
                    აირჩიეთ ტიპი <strong>„Web app“</strong>, მიუთითეთ:
                    <ul className="list-disc list-inside pl-4 mt-1 space-y-0.5 text-slate-600">
                      <li>Execute as: <strong>Me (თქვენი მეილი)</strong></li>
                      <li>Who has access: <strong>Anyone (ყველა)</strong></li>
                    </ul>
                  </li>
                  <li>
                    დააჭირეთ <strong>Deploy</strong>, მიანიჭეთ წვდომა და მიღებული <strong>Web app URL</strong> ჩასვით „Webhook URL“ ველში.
                  </li>
                </ol>
              </div>

              {/* Code Box */}
              <div className="relative rounded-2xl bg-slate-900 border border-slate-800 p-4 text-slate-200">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs font-mono text-slate-400">
                  <span>Google Apps Script (Code.gs)</span>
                  <button
                    onClick={handleCopyCode}
                    className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg transition-colors text-xs font-semibold cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-300" />
                        დაკოპირდა!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        კოდის კოპირება
                      </>
                    )}
                  </button>
                </div>
                <pre className="text-xs font-mono overflow-x-auto text-emerald-400 max-h-60 p-2">
                  {GOOGLE_APPS_SCRIPT_SAMPLE.replace(
                    DEFAULT_TEACHER_EMAIL,
                    tempEmail || DEFAULT_TEACHER_EMAIL
                  )}
                </pre>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSaveSettings} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  მასწავლებლის იმეილი (შედეგების მიმღები)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    value={tempEmail}
                    onChange={(e) => setTempEmail(e.target.value)}
                    placeholder="მაგ: lomidze.kote1@gmail.com"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-sm focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 outline-hidden"
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  ამ მისამართზე გაიგზავნება მოსწავლის პასუხები Apps Script-ის მეშვეობით.
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Google Apps Script Web App URL (Webhook)
                </label>
                <input
                  type="url"
                  value={tempUrl}
                  onChange={(e) => setTempUrl(e.target.value)}
                  placeholder="https://script.google.com/macros/s/AKfycbx.../exec"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-mono focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 outline-hidden"
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  თუ ჯერ არ გაქვთ Webhook URL შექმნილი, მოსწავლეს მაინც შეუძლია ტესტის გაგზავნა პირდაპირი იმეილით ან ანგარიშის კოპირებით.
                </p>
              </div>

              {saveSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-semibold flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-600" />
                  პარამეტრები წარმატებით შეინახა!
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors cursor-pointer"
                >
                  პარამეტრების შენახვა
                </button>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            დახურვა
          </button>
        </div>

      </div>
    </div>
  );
};
