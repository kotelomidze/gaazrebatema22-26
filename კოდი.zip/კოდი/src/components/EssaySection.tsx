import React, { useState } from 'react';
import { useExam } from '../data/examSource';
import { PoemViewer } from './PoemViewer';
import {
  PenTool,
  BookOpen,
  Info,
  CheckCircle2,
  AlertTriangle,
  Columns,
  Maximize2,
  Minimize2,
  FileText
} from 'lucide-react';

interface EssaySectionProps {
  essayText: string;
  onEssayChange: (text: string) => void;
  wordCount: number;
  onOpenPoem?: () => void;
}

export const EssaySection: React.FC<EssaySectionProps> = ({
  essayText,
  onEssayChange,
  wordCount,
  onOpenPoem,
}) => {
  const [showGuidelines, setShowGuidelines] = useState<boolean>(false);
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg'>('base');

  const exam = useExam();
  const ESSAY_PROMPT = exam.essay;
  const minWords = ESSAY_PROMPT.minWords;
  const isWordCountSufficient = wordCount >= minWords;
  const wordsRemaining = Math.max(0, minWords - wordCount);
  const paragraphsCount = essayText.trim() ? essayText.split(/\n+/).filter(p => p.trim().length > 0).length : 0;
  const characterCount = essayText.length;

  const fontClass = {
    sm: 'text-sm leading-relaxed',
    base: 'text-base leading-relaxed',
    lg: 'text-lg leading-loose',
  }[fontSize];

  return (
    <div className="space-y-5">
      {/* Top Banner with Title and Instructions */}
      <div className="bg-white rounded-2xl p-5 md:p-6 border border-slate-200/80 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-purple-50 text-purple-700 border border-purple-100">
              კომპონენტი II • 34 ქულა
            </span>
            <span className="text-xs font-semibold text-slate-500">
              დავალება 12 • არგუმენტირებული ესე
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Guidelines Toggle */}
            <button
              onClick={() => setShowGuidelines(!showGuidelines)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
            >
              <Info className="w-3.5 h-3.5 text-slate-500" />
              {showGuidelines ? 'ინსტრუქციის დამალვა' : 'მოთხოვნები & წესები'}
            </button>

            {/* Text Modal */}
            {onOpenPoem && (
              <button
                onClick={onOpenPoem}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-amber-900 bg-amber-100/80 hover:bg-amber-200 rounded-lg transition-colors cursor-pointer"
              >
                <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                ტექსტის წაკითხვა
              </button>
            )}
          </div>
        </div>

        {/* PROMPT BOX - Always visible at the top as requested */}
        <div className="p-4 md:p-5 rounded-xl bg-gradient-to-br from-purple-50/70 via-indigo-50/30 to-amber-50/40 border border-purple-200/80 shadow-xs">
          <div className="text-xs font-bold uppercase tracking-wider text-purple-900 mb-1.5 flex items-center gap-1.5">
            <PenTool className="w-3.5 h-3.5 text-purple-700" />
            თემის სათაური და პირობა:
          </div>

          {/* Quote */}
          <blockquote className="text-base md:text-lg font-bold text-slate-900 font-serif my-2 pl-3 border-l-4 border-purple-600 leading-snug">
            {ESSAY_PROMPT.quote}
          </blockquote>

          {/* Prompt Instruction */}
          <p className="text-sm font-semibold text-indigo-950 mt-2 leading-relaxed">
            {ESSAY_PROMPT.instruction}
          </p>
        </div>

        {/* Collapsible Guidelines Box */}
        {showGuidelines && (
          <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-700 space-y-2 animate-in fade-in duration-200">
            <div className="font-bold text-slate-900 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-indigo-600" />
              შეფასების ძირითადი კრიტერიუმები & გაითვალისწინეთ:
            </div>
            <ul className="list-disc list-inside space-y-1.5 text-slate-600 pl-1">
              {ESSAY_PROMPT.guidelines.map((g, i) => (
                <li key={i} className="leading-relaxed">{g}</li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Main Workspace (Split View / Full View) */}
      <div className="grid grid-cols-1 gap-6">

        {/* Right: Essay Writing Canvas */}
        <div className="w-full">
          <div className="bg-white rounded-2xl p-5 md:p-6 border border-slate-200/80 shadow-xs flex flex-col h-full min-h-[650px]">
            
            {/* Writing Controls Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 mb-4">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-purple-100 text-purple-800">
                  <FileText className="w-4 h-4" />
                </div>
                <span className="text-xs font-bold text-slate-700">თხზულების საწერი არე</span>
              </div>

              {/* Font Sizer */}
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs font-medium text-slate-600">
                <span className="text-[10px] text-slate-400 px-1">შრიფტი:</span>
                <button
                  onClick={() => setFontSize('sm')}
                  className={`px-2 py-0.5 rounded ${fontSize === 'sm' ? 'bg-white shadow-xs font-bold text-indigo-700' : 'hover:text-slate-900'}`}
                >
                  A-
                </button>
                <button
                  onClick={() => setFontSize('base')}
                  className={`px-2 py-0.5 rounded ${fontSize === 'base' ? 'bg-white shadow-xs font-bold text-indigo-700' : 'hover:text-slate-900'}`}
                >
                  A
                </button>
                <button
                  onClick={() => setFontSize('lg')}
                  className={`px-2 py-0.5 rounded ${fontSize === 'lg' ? 'bg-white shadow-xs font-bold text-indigo-700' : 'hover:text-slate-900'}`}
                >
                  A+
                </button>
              </div>
            </div>

            {/* Writing Area Textarea */}
            <div className="flex-1 relative flex flex-col">
              <textarea
                value={essayText}
                onChange={(e) => onEssayChange(e.target.value)}
                placeholder="დაიწყეთ თხზულების წერა აქ...&#10;&#10;გამოყავით აბზაცები, მოიყვანეთ არგუმენტები და პარალელები როგორც მოცემული ტექსტიდან, ისე თანამედროვეობიდან."
                className={`w-full flex-1 p-4 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/20 outline-hidden transition-all resize-y min-h-[480px] bg-slate-50/40 text-slate-900 ${fontClass}`}
              />
            </div>

            {/* Word Count & Status Footer */}
            <div className="mt-4 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              
              {/* Word Count Indicator with Warning/Success */}
              <div className="flex items-center gap-3">
                {isWordCountSufficient ? (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    სიტყვების რაოდენობა: {wordCount} (საკმარისია ≥ 150)
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-50 text-amber-900 border border-amber-300 text-xs font-bold">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>
                      {wordCount} / 150 სიტყვა (დარჩენილია {wordsRemaining})
                    </span>
                  </div>
                )}
              </div>

              {/* Stats Summary */}
              <div className="flex items-center gap-3 text-xs text-slate-500 font-medium">
                <span>აბზაცები: <strong className="text-slate-700">{paragraphsCount}</strong></span>
                <span>•</span>
                <span>სიმბოლოები: <strong className="text-slate-700">{characterCount}</strong></span>
              </div>
            </div>

            {/* Warning reminder if less than 150 words */}
            {!isWordCountSufficient && wordCount > 0 && (
              <p className="text-[11px] text-amber-700 mt-2">
                * გაითვალისწინეთ: ნაშრომი, რომლის მოცულობა არ აღემატება 150 სიტყვას, ენობრივი თვალსაზრისით არ შეფასდება.
              </p>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
