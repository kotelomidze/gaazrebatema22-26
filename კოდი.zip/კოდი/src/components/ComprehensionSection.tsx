import React from 'react';
import { useExam } from '../data/examSource';
import { CheckCircle2, HelpCircle, BookOpen, ArrowRight } from 'lucide-react';

interface ComprehensionSectionProps {
  answers: Record<number, string>;
  onSelectAnswer: (questionId: number, optionKey: 'ა' | 'ბ' | 'გ' | 'დ') => void;
  onOpenPoem?: () => void;
  onGoToEssay?: () => void;
}

export const ComprehensionSection: React.FC<ComprehensionSectionProps> = ({
  answers,
  onSelectAnswer,
  onOpenPoem,
  onGoToEssay,
}) => {
  const COMPREHENSION_QUESTIONS = useExam().questions;
  const totalQuestions = COMPREHENSION_QUESTIONS.length;
  const answeredCount = Object.keys(answers).length;
  const progressPercent = Math.round((answeredCount / totalQuestions) * 100);

  const scrollToQuestion = (qId: number) => {
    const el = document.getElementById(`question-card-${qId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // კითხვებზე გადასვლა და ტექსტის გახსნა — თითოეულ კითხვასთან, რომ ზევით
  // ასქროლვა არ დასჭირდეს
  const QuestionTools = ({ currentId }: { currentId?: number }) => (
    <div className="flex flex-wrap items-center gap-1.5">
      {onOpenPoem && (
        <button
          onClick={onOpenPoem}
          className="inline-flex items-center gap-1.5 px-2.5 h-8 text-xs font-semibold text-amber-900 bg-amber-100/80 hover:bg-amber-200 rounded-lg transition-colors shrink-0 cursor-pointer"
          title="ტექსტის წაკითხვა"
        >
          <BookOpen className="w-3.5 h-3.5 text-amber-700" />
          <span className="hidden sm:inline">ტექსტი</span>
        </button>
      )}
      {COMPREHENSION_QUESTIONS.map(q => {
        const isAnswered = !!answers[q.id];
        const isCurrent = q.id === currentId;
        return (
          <button
            key={q.id}
            onClick={() => scrollToQuestion(q.id)}
            className={`w-8 h-8 rounded-lg text-xs font-bold transition-all flex items-center justify-center cursor-pointer ${
              isCurrent
                ? 'bg-slate-900 text-white shadow-xs'
                : isAnswered
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
            title={`კითხვა ${q.number} ${isAnswered ? '(მონიშნულია: ' + answers[q.id] + ')' : '(შეუვსებელია)'}`}
          >
            {q.number}
          </button>
        );
      })}
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Top Section Summary Card */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-100">
                კომპონენტი I • 10 ქულა
              </span>
              <span className="text-xs font-semibold text-slate-500">
                10 დახურული კითხვა
              </span>
            </div>
            <h2 className="text-lg md:text-xl font-bold text-slate-800 mt-1.5">
              ტექსტის გააზრება (კითხვები 2 – 11)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              ყურადღებით წაიკითხეთ თითოეული კითხვა და ოთხი სავარაუდო პასუხიდან აირჩიეთ ერთი სწორი.
            </p>
          </div>

          {/* Quick Stats & Text Toggle */}
          <div className="flex items-center gap-3">
            {onOpenPoem && (
              <button
                onClick={onOpenPoem}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-amber-900 bg-amber-100/80 hover:bg-amber-200 rounded-xl transition-colors shrink-0 shadow-xs cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-amber-700" />
                ტექსტის წაკითხვა
              </button>
            )}
            <div className="bg-slate-50 border border-slate-200/70 rounded-xl px-3.5 py-2 text-right">
              <div className="text-xs text-slate-500 font-medium">შევსებულია</div>
              <div className="text-sm font-bold text-indigo-600">
                {answeredCount} / {totalQuestions} ({progressPercent}%)
              </div>
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mt-4">
          <div
            className="bg-indigo-600 h-full transition-all duration-300 rounded-full"
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        {/* Question Jumper Bar */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-1.5">
          <span className="text-xs font-medium text-slate-500 mr-1">გადასვლა:</span>
          <QuestionTools />
        </div>
      </div>

      {/* Questions List */}
      <div className="space-y-4">
        {COMPREHENSION_QUESTIONS.map(q => {
          const selectedOption = answers[q.id];
          const isAnswered = !!selectedOption;

          return (
            <div
              key={q.id}
              id={`question-card-${q.id}`}
              className={`bg-white rounded-2xl p-5 md:p-6 border transition-all scroll-mt-24 ${
                isAnswered
                  ? 'border-indigo-200 shadow-xs'
                  : 'border-slate-200/90 shadow-xs hover:border-slate-300'
              }`}
            >
              {/* Question Header */}
              <div className="flex flex-wrap items-center gap-x-3 gap-y-2 mb-3">
                <div className="flex items-center gap-2 shrink-0">
                  <span className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-indigo-100 text-indigo-800 font-bold text-xs">
                    {q.number}
                  </span>
                  <span className="text-xs font-semibold text-slate-400">
                    ({q.points} ქულა)
                  </span>
                </div>

                <QuestionTools currentId={q.id} />

                {isAnswered && (
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md ml-auto">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    მონიშნულია: {selectedOption}
                  </span>
                )}
              </div>

              {/* Question Text */}
              <h3 className="text-base font-semibold text-slate-900 leading-relaxed mb-4">
                {q.text}
              </h3>

              {/* Options Grid */}
              <div className="space-y-2.5">
                {q.options.map(option => {
                  const isSelected = selectedOption === option.key;

                  return (
                    <label
                      key={option.key}
                      onClick={() => onSelectAnswer(q.id, option.key)}
                      className={`flex items-start gap-3 p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                        isSelected
                          ? 'bg-indigo-50/70 border-indigo-500 shadow-xs ring-1 ring-indigo-500/20'
                          : 'bg-white border-slate-200 hover:bg-slate-50 hover:border-slate-300'
                      }`}
                    >
                      <div
                        className={`w-6 h-6 rounded-lg flex items-center justify-center font-bold text-xs shrink-0 transition-colors mt-0.5 ${
                          isSelected
                            ? 'bg-indigo-600 text-white'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {option.key}
                      </div>
                      <span className={`text-sm leading-relaxed ${
                        isSelected ? 'font-medium text-indigo-950' : 'text-slate-700'
                      }`}>
                        {option.text}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Nav */}
      {onGoToEssay && (
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-sm font-bold text-slate-800">
              შემდეგი ნაბიჯი: კომპონენტი II – თხზულება
            </div>
            <div className="text-xs text-slate-500">
              გადასვლა 34-ქულიანი თემის წერის სივრცეზე
            </div>
          </div>
          <button
            onClick={onGoToEssay}
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm rounded-xl shadow-xs transition-colors cursor-pointer"
          >
            თხზულებაზე გადასვლა
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
