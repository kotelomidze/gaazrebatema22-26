import React, { useState } from 'react';
import { StudentInfo, SubmissionPayload } from '../types';
import { DEFAULT_TEACHER_EMAIL } from '../data/examData';
import { useExam, testLabel } from '../data/examSource';
import confetti from 'canvas-confetti';
import {
  X,
  Send,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  Mail,
  Download,
  FileText,
  RotateCcw,
  Loader2
} from 'lucide-react';

interface SubmissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentInfo;
  answers: Record<number, string>;
  essayText: string;
  essayWordCount: number;
  webhookUrl: string;
  teacherEmail: string;
  onResetExam: () => void;
}

export const SubmissionModal: React.FC<SubmissionModalProps> = ({
  isOpen,
  onClose,
  student,
  answers,
  essayText,
  essayWordCount,
  webhookUrl,
  teacherEmail,
  onResetExam,
}) => {
  const [status, setStatus] = useState<'confirm' | 'submitting' | 'success' | 'error'>('confirm');
  const [errorMessage, setErrorMessage] = useState('');
  const [copied, setCopied] = useState(false);

  const exam = useExam();
  const COMPREHENSION_QUESTIONS = exam.questions;
  const ESSAY_PROMPT = exam.essay;

  if (!isOpen) return null;

  const totalQuestions = COMPREHENSION_QUESTIONS.length;
  const answeredQuestionsCount = Object.keys(answers).length;
  const hasEssay = essayText.trim().length > 0;
  const hasComprehension = answeredQuestionsCount > 0;

  // Calculate score if answers match key
  let comprehensionScore = 0;
  COMPREHENSION_QUESTIONS.forEach(q => {
    if (answers[q.id] && answers[q.id] === q.correctAnswer) {
      comprehensionScore += q.points;
    }
  });

  const generateReportText = () => {
    let report = `========================================================\n`;
    report += `საგამოცდო ნაშრომი: ქართული ენა და ლიტერატურა\n`;
    report += `ტექსტი: ${testLabel(exam)}\n`;
    report += `========================================================\n\n`;
    report += `მოსწავლე: ${student.firstName} ${student.lastName}\n`;
    if (student.className) {
      report += `კლასი/ჯგუფი: ${student.className}\n`;
    }
    report += `დაწყების დრო: ${new Date(student.startedAt).toLocaleString('ka-GE')}\n`;
    report += `გაგზავნის დრო: ${new Date().toLocaleString('ka-GE')}\n\n`;

    report += `--------------------------------------------------------\n`;
    report += `1. ტექსტის გააზრება (${answeredQuestionsCount}/${totalQuestions} პასუხი, ქულა: ${comprehensionScore}/${totalQuestions})\n`;
    report += `--------------------------------------------------------\n`;
    COMPREHENSION_QUESTIONS.forEach(q => {
      const ans = answers[q.id] || '(არ არის მონიშნული)';
      report += `კითხვა ${q.number}: ${ans}\n`;
    });

    report += `\n--------------------------------------------------------\n`;
    report += `2. თხზულება (დავალება 12 - 34 ქულა)\n`;
    report += `სათაური: ${ESSAY_PROMPT.quote}\n`;
    report += `სიტყვების რაოდენობა: ${essayWordCount} სიტყვა\n`;
    report += `--------------------------------------------------------\n`;
    report += hasEssay ? essayText : '(თხზულება არ არის შესრულებული)\n';

    return report;
  };

  const handleCopyReport = () => {
    navigator.clipboard.writeText(generateReportText());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([generateReportText()], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `ნაშრომი_${student.firstName}_${student.lastName}_${exam.id}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleOpenMailClient = () => {
    const subject = encodeURIComponent(`საგამოცდო ნაშრომი: ${student.firstName} ${student.lastName} — ${testLabel(exam)}`);
    const body = encodeURIComponent(generateReportText());
    const mailtoLink = `mailto:${teacherEmail || DEFAULT_TEACHER_EMAIL}?subject=${subject}&body=${body}`;
    window.open(mailtoLink, '_blank');
  };

  const handleFinalSubmit = async () => {
    setStatus('submitting');
    setErrorMessage('');

    const payload: SubmissionPayload = {
      student,
      submittedAt: new Date().toISOString(),
      comprehensionAnswers: answers,
      comprehensionTotal: comprehensionScore,
      comprehensionMaxPoints: totalQuestions,
      essayText: essayText.trim(),
      essayWordCount,
      testId: exam.id,
      testTitle: testLabel(exam),
      hasEssay,
      hasComprehension,
    };

    // If teacher provided a Webhook URL (Google Apps Script)
    if (webhookUrl && webhookUrl.trim().startsWith('http')) {
      try {
        await fetch(webhookUrl, {
          method: 'POST',
          mode: 'no-cors', // standard for Google Apps Script Web App endpoints
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(payload),
        });
      } catch (err: any) {
        console.warn('Webhook post error:', err);
      }
    }

    // Trigger confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    } catch {
      // ignore
    }

    setStatus('success');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="p-5 md:p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-600 rounded-xl text-white">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base md:text-lg font-bold">
                {status === 'success' ? 'ტესტი წარმატებით გაიგზავნა!' : 'ტესტის გაგზავნის დადასტურება'}
              </h2>
              <p className="text-xs text-slate-300">
                მოსწავლე: {student.firstName} {student.lastName} {student.className ? `(${student.className})` : ''}
              </p>
            </div>
          </div>
          {status !== 'submitting' && (
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">
          
          {status === 'confirm' && (
            <div className="space-y-4">
              <p className="text-sm text-slate-700">
                გთხოვთ გადაამოწმოთ თქვენი შესრულებული სამუშაო საბოლოო გაგზავნამდე:
              </p>

              {/* Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                
                {/* Comprehension summary */}
                <div className={`p-4 rounded-2xl border ${
                  hasComprehension ? 'bg-indigo-50/70 border-indigo-200' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div className="text-xs font-bold uppercase text-indigo-800 mb-1">
                    I. ტექსტის გააზრება
                  </div>
                  <div className="text-lg font-extrabold text-slate-900">
                    {answeredQuestionsCount} / {totalQuestions} კითხვა
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {answeredQuestionsCount === totalQuestions
                      ? '✓ ყველა კითხვა შევსებულია'
                      : answeredQuestionsCount > 0
                      ? `${totalQuestions - answeredQuestionsCount} კითხვა დარჩა შეუვსებელი`
                      : 'არცერთი კითხვა არ არის შევსებული'}
                  </div>
                </div>

                {/* Essay summary */}
                <div className={`p-4 rounded-2xl border ${
                  hasEssay ? 'bg-purple-50/70 border-purple-200' : 'bg-slate-50 border-slate-200'
                }`}>
                  <div className="text-xs font-bold uppercase text-purple-800 mb-1">
                    II. თხზულება (დავალება 12)
                  </div>
                  <div className="text-lg font-extrabold text-slate-900">
                    {essayWordCount} სიტყვა
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {essayWordCount >= 150
                      ? '✓ მოცულობის მოთხოვნა შესრულებულია (≥ 150)'
                      : hasEssay
                      ? '⚠️ 150 სიტყვაზე ნაკლებია'
                      : 'თხზულება არ არის დაწერილი'}
                  </div>
                </div>

              </div>

              {!hasComprehension && !hasEssay && (
                <div className="p-3 bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold rounded-xl flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
                  <span>ყურადღება: არც გააზრების კითხვები და არც თხზულება ჯერ არ შეგივსიათ.</span>
                </div>
              )}

              {/* Destination info */}
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center gap-2">
                <Mail className="w-4 h-4 text-slate-500 shrink-0" />
                <span>
                  ნაშრომი მიუვა მასწავლებელს: <strong>{teacherEmail || DEFAULT_TEACHER_EMAIL}</strong>
                </span>
              </div>
            </div>
          )}

          {status === 'submitting' && (
            <div className="py-12 text-center space-y-3">
              <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mx-auto" />
              <div className="text-base font-bold text-slate-800">
                ნაშრომი იგზავნება...
              </div>
              <p className="text-xs text-slate-500">
                გთხოვთ დაელოდოთ მონაცემების გადაცემას.
              </p>
            </div>
          )}

          {status === 'success' && (
            <div className="space-y-5 text-center">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle2 className="w-9 h-9" />
              </div>

              <div>
                <h3 className="text-lg font-bold text-slate-900">
                  თქვენი ნაშრომი წარმატებით მიღებულია!
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  შედეგები გაიგზავნა მასწავლებელთან ({teacherEmail || DEFAULT_TEACHER_EMAIL}).
                </p>
              </div>

              {/* Action Buttons */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5 text-left">
                <div className="text-xs font-bold text-slate-700 mb-2">
                  დამატებითი პარამეტრები (ნაშრომის შენახვა/გადაგზავნა):
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    onClick={handleCopyReport}
                    className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl text-xs font-semibold text-slate-800 transition-colors cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                    {copied ? 'ტექსტი დაკოპირდა!' : 'ნაშრომის კოპირება'}
                  </button>

                  <button
                    onClick={handleDownload}
                    className="flex items-center justify-center gap-2 py-2.5 px-3 bg-white border border-slate-300 hover:bg-slate-100 rounded-xl text-xs font-semibold text-slate-800 transition-colors cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-slate-500" />
                    ჩამოტვირთვა (.txt)
                  </button>
                </div>

                <button
                  onClick={handleOpenMailClient}
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-3 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 rounded-xl text-xs font-bold text-indigo-900 transition-colors cursor-pointer"
                >
                  <Mail className="w-3.5 h-3.5 text-indigo-600" />
                  პირდაპირი იმეილის გახსნა (სარეზერვო)
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Footer actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          {status === 'confirm' ? (
            <>
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                უკან დაბრუნება
              </button>
              <button
                onClick={handleFinalSubmit}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                საბოლოო გაგზავნა
              </button>
            </>
          ) : status === 'success' ? (
            <div className="flex items-center justify-between w-full">
              <button
                onClick={onResetExam}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                ახალი ტესტის დაწყება
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
              >
                დასრულება
              </button>
            </div>
          ) : null}
        </div>

      </div>
    </div>
  );
};
