import React, { createContext, useContext } from 'react';
import { ExamTest, TestSummary } from '../types';

/**
 * ტესტების წყარო — public/tests/.
 * ახალი ტესტის დამატება = ერთი JSON ფაილი + index.json-ის განახლება.
 * კომპონენტების კოდი არ იცვლება.
 */

// ბაზისური მისამართი — მუშაობს როგორც საიტის ფესვში, ისე ქვესაქაღალდეში
const base: string =
  (import.meta as unknown as { env?: { BASE_URL?: string } }).env?.BASE_URL || '/';

export async function loadTestIndex(): Promise<TestSummary[]> {
  const res = await fetch(`${base}tests.json`, { cache: 'no-store' });
  if (!res.ok) throw new Error('tests.json ვერ ჩაიტვირთა');
  const data = await res.json();
  return (data.tests || []) as TestSummary[];
}

export async function loadTest(summary: TestSummary): Promise<ExamTest> {
  const file = summary.file || `test-${summary.id}.json`;
  const res = await fetch(`${base}${file}`, { cache: 'no-store' });
  if (!res.ok) throw new Error(`${file} ვერ ჩაიტვირთა`);
  return (await res.json()) as ExamTest;
}

/** საიტის პარამეტრები — public/config.json, იკითხება გაშვებისას (build არ სჭირდება) */
export async function loadSiteConfig(): Promise<{ webhookUrl?: string; teacherEmail?: string }> {
  try {
    const res = await fetch(`${base}config.json`, { cache: 'no-store' });
    if (!res.ok) return {};
    return await res.json();
  } catch {
    return {};
  }
}

const ExamContext = createContext<ExamTest | null>(null);

export const ExamProvider: React.FC<{ test: ExamTest; children: React.ReactNode }> = ({
  test,
  children,
}) => <ExamContext.Provider value={test}>{children}</ExamContext.Provider>;

/** მიმდინარე ტესტი. კომპონენტებში ცვლადების სახელები უცვლელი რჩება. */
export function useExam(): ExamTest {
  const test = useContext(ExamContext);
  if (!test) throw new Error('useExam უნდა გამოიძახოს ExamProvider-ის შიგნით');
  return test;
}

/** ტესტის სათაური ერთ სტრიქონად: „დავით გურამიშვილი – „დავითიანი““ */
export function testLabel(t: ExamTest | TestSummary): string {
  const work = (t as ExamTest).work || (t as TestSummary).work;
  const name = work ? `„${work}“` : t.source;
  return t.author ? `${t.author} – ${name}` : name;
}
