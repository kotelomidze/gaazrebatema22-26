/**
 * ტესტების შიგთავსი აქ აღარ ინახება — თითოეული ტექსტი ცალკე JSON ფაილია:
 *   public/tests/<id>.json   (და public/tests/index.json — სია)
 * ახალი ტექსტის დამატება: python3 tools/pdf_to_json.py pdfs/*.pdf
 * აქ რჩება მხოლოდ ის, რაც ყველა ტესტისთვის საერთოა.
 */

import { SITE_CONFIG } from '../config';

export const DEFAULT_TEACHER_EMAIL = SITE_CONFIG.teacherEmail;

// Sample Google Apps Script code for teacher to copy-paste in 30 seconds
export const GOOGLE_APPS_SCRIPT_SAMPLE = `// -------------------------------------------------------------
// Google Apps Script - საგამოცდო ტესტის პასუხების მიმღები
// დააკოპირეთ ეს კოდი script.google.com - ზე და გამოაქვეყნეთ Web App-ად
// -------------------------------------------------------------

function doPost(e) {
  try {
    var data = JSON.parse(e.postData.contents);
    var recipient = "${DEFAULT_TEACHER_EMAIL}"; // თქვენი იმეილი
    var subject = "საგამოცდო ნაშრომი: " + data.student.firstName + " " + data.student.lastName + " — " + (data.testTitle || "");
    
    var body = "სტუდენტი: " + data.student.firstName + " " + data.student.lastName + "\\n";
    if (data.student.className) {
      body += "კლასი/ჯგუფი: " + data.student.className + "\\n";
    }
    body += "ტექსტი: " + (data.testTitle || "-") + "\\n";
    body += "თარიღი: " + (data.submittedAt || new Date().toLocaleString()) + "\\n\\n";
    
    body += "========================================\\n";
    body += "1. ტექსტის გააზრება (ქულა: " + data.comprehensionTotal + " / " + data.comprehensionMaxPoints + ")\\n";
    body += "========================================\\n";
    for (var key in data.comprehensionAnswers) {
      body += "კითხვა " + key + ": " + data.comprehensionAnswers[key] + "\\n";
    }
    
    body += "\\n========================================\\n";
    body += "2. თხზულება (სიტყვების რაოდენობა: " + data.essayWordCount + ")\\n";
    body += "========================================\\n";
    body += data.essayText ? data.essayText : "(თხზულება არ არის შევსებული)";
    
    // იმეილის გაგზავნა
    MailApp.sendEmail({
      to: recipient,
      subject: subject,
      body: body
    });
    
    return ContentService.createTextOutput(JSON.stringify({
      status: "success",
      message: "ტესტი წარმატებით მიღებულია და გაგზავნილია იმეილზე!"
    })).setMimeType(ContentService.MimeType.JSON);
    
  } catch (error) {
    return ContentService.createTextOutput(JSON.stringify({
      status: "error",
      error: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}
`;
