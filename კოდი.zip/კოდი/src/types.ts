export interface StudentInfo {
  firstName: string;
  lastName: string;
  className?: string;
  startedAt: string;
}

export interface Option {
  key: 'ა' | 'ბ' | 'გ' | 'დ';
  text: string;
}

export interface Question {
  id: number;
  number: number;
  points: number;
  text: string;
  options: Option[];
  correctAnswer?: 'ა' | 'ბ' | 'გ' | 'დ';
}

export interface TextPoemSection {
  id: string;
  title: string;
  subtitle?: string;
  /** ლექსისთვის: სტროფები, თითოეული სტრიქონების მასივი */
  stanzas?: string[][];
  /** პროზისთვის: აბზაცები */
  paragraphs?: string[];
}

/** ერთი სრული ტესტი — public/tests/<id>.json */
export interface ExamTest {
  id: string;
  title: string;
  author: string;
  work?: string;
  source: string;
  sections: TextPoemSection[];
  questions: Question[];
  essay: EssayPrompt;
}

/** public/tests/index.json-ის ჩანაწერი */
export interface TestSummary {
  id: string;
  file: string;
  title: string;
  author: string;
  work?: string;
  source: string;
  questionCount: number;
  hasEssay: boolean;
  keyComplete: boolean;
  order?: number;
}

export interface EssayPrompt {
  id: number;
  points: number;
  quote: string;
  instruction: string;
  guidelines: string[];
  minWords: number;
}

export interface SubmissionPayload {
  student: StudentInfo;
  submittedAt: string;
  comprehensionAnswers: Record<number, string>;
  comprehensionTotal: number;
  comprehensionMaxPoints: number;
  essayText: string;
  essayWordCount: number;
  testId: string;
  testTitle: string;
  hasEssay: boolean;
  hasComprehension: boolean;
}
