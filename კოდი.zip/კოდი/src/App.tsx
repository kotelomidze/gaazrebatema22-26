import React, { useState, useEffect } from 'react';
import { StudentInfo, ExamTest, TestSummary } from './types';
import { SITE_CONFIG } from './config';
import { ExamProvider, loadTestIndex, loadTest, loadSiteConfig } from './data/examSource';
import { StartScreen } from './components/StartScreen';
import { StudentHeader } from './components/StudentHeader';
import { ComprehensionSection } from './components/ComprehensionSection';
import { EssaySection } from './components/EssaySection';
import { PoemViewer } from './components/PoemViewer';
import { PoemModal } from './components/PoemModal';
import { SubmissionModal } from './components/SubmissionModal';
import { TeacherConfigModal } from './components/TeacherConfigModal';

const STORAGE_KEYS = {
  STUDENT: 'georgian_exam_student',
  ANSWERS: 'georgian_exam_answers',
  ESSAY: 'georgian_exam_essay',
  WEBHOOK: 'georgian_exam_webhook_url',
  TEACHER_EMAIL: 'georgian_exam_teacher_email',
  TEST: 'georgian_exam_test_id',
  SESSION: 'georgian_exam_session',
};

/**
 * მიმდინარე გამოცდა sessionStorage-შია, არა localStorage-ში.
 * ეს ორ რამეს აწონასწორებს: „Desktop site“-ზე გადართვა ან შემთხვევითი
 * გადატვირთვა ნაშრომს არ შლის, ჩანართის დახურვის შემდეგ კი გამოცდა
 * თავიდან იწყება — ძველი ნაშრომი შემდეგ მოსწავლეს არ ხვდება.
 */
function readSession(): any {
  try {
    return JSON.parse(sessionStorage.getItem(STORAGE_KEYS.SESSION) || 'null');
  } catch (e) {
    return null;
  }
}

export default function App() {
  const restored = readSession();

  const [student, setStudent] = useState<StudentInfo | null>(restored?.student ?? null);

  const [tests, setTests] = useState<TestSummary[]>([]);
  // ტექსტი ავტომატურად არ ირჩევა — მოსწავლემ თავად უნდა აირჩიოს
  const [selectedTestId, setSelectedTestId] = useState<string>(restored?.testId ?? '');
  const [exam, setExam] = useState<ExamTest | null>(null);
  const [loadError, setLoadError] = useState<string>('');

  const [answers, setAnswers] = useState<Record<number, string>>(restored?.answers || {});
  const [essayText, setEssayText] = useState<string>(restored?.essayText || '');

  // config.ts-ის მისამართი ყველა მოსწავლესთან მოქმედებს;
  // ლოკალური პარამეტრი მხოლოდ შემოწმებისთვისაა
  const [webhookUrl, setWebhookUrl] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.WEBHOOK) || SITE_CONFIG.webhookUrl;
  });

  const [teacherEmail, setTeacherEmail] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.TEACHER_EMAIL) || SITE_CONFIG.teacherEmail;
  });

  const [activeTab, setActiveTab] = useState<'comprehension' | 'essay'>('comprehension');
  const [isPoemModalOpen, setIsPoemModalOpen] = useState(false);
  const [isSubmissionModalOpen, setIsSubmissionModalOpen] = useState(false);
  const [isTeacherConfigOpen, setIsTeacherConfigOpen] = useState(false);

  // საიტის პარამეტრები — config.json-ის რედაქტირება GitHub-ზე მაშინვე მოქმედებს
  useEffect(() => {
    loadSiteConfig().then(cfg => {
      if (cfg.webhookUrl && !localStorage.getItem(STORAGE_KEYS.WEBHOOK)) {
        setWebhookUrl(cfg.webhookUrl);
      }
      if (cfg.teacherEmail && !localStorage.getItem(STORAGE_KEYS.TEACHER_EMAIL)) {
        setTeacherEmail(cfg.teacherEmail);
      }
    });
  }, []);

  // ტესტების სიის ჩატვირთვა
  useEffect(() => {
    loadTestIndex()
      .then(list => setTests(list))
      .catch(err => setLoadError(err.message));
  }, []);

  // არჩეული ტესტის ჩატვირთვა + მისი შენახული პასუხების აღდგენა
  useEffect(() => {
    const summary = tests.find(t => t.id === selectedTestId);
    if (!summary) {
      setExam(null);
      return;
    }
    let cancelled = false;
    loadTest(summary)
      .then(t => {
        if (cancelled) return;
        setExam(t);
        // სხვა ტექსტზე გადასვლისას ძველი პასუხები არ უნდა გადმოჰყვეს;
        // აღდგენილ სესიაში კი შენარჩუნდება
        const session = readSession();
        if (!session || session.testId !== t.id) {
          setAnswers({});
          setEssayText('');
        }
      })
      .catch(err => !cancelled && setLoadError(err.message));
    return () => {
      cancelled = true;
    };
  }, [selectedTestId, tests]);

  // გამოცდის დაწყების მომენტი — ხანგრძლივობა იმეილში იგზავნება
  const [startedAt, setStartedAt] = useState<number | null>(restored?.startedAt ?? null);

  useEffect(() => {
    // ათვლა ერთხელ იწყება; აღდგენილ სესიაში ძველი დრო რჩება
    setStartedAt(prev => (student ? (prev ?? Date.now()) : null));
  }, [student]);

  // მიმდინარე მდგომარეობის ჩაწერა სესიაში
  useEffect(() => {
    try {
      if (!student) {
        sessionStorage.removeItem(STORAGE_KEYS.SESSION);
        return;
      }
      sessionStorage.setItem(STORAGE_KEYS.SESSION, JSON.stringify({
        student, testId: selectedTestId, answers, essayText, startedAt,
      }));
    } catch (e) { /* პრივატულ რეჟიმში sessionStorage მიუწვდომელია */ }
  }, [student, selectedTestId, answers, essayText, startedAt]);

  // შემთხვევითი გადატვირთვისგან დაცვა — ბრაუზერი კითხავს დადასტურებას
  useEffect(() => {
    if (!student) return;
    const hasWork = Object.keys(answers).length > 0 || essayText.trim().length > 0;
    if (!hasWork) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [student, answers, essayText]);

  const handleSaveWebhookUrl = (url: string) => {
    setWebhookUrl(url);
    localStorage.setItem(STORAGE_KEYS.WEBHOOK, url);
  };

  const handleSaveTeacherEmail = (email: string) => {
    setTeacherEmail(email);
    localStorage.setItem(STORAGE_KEYS.TEACHER_EMAIL, email);
  };

  const handleSelectAnswer = (questionId: number, optionKey: 'ა' | 'ბ' | 'გ' | 'დ') => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: optionKey,
    }));
  };

  const handleResetExam = () => {
    try { sessionStorage.removeItem(STORAGE_KEYS.SESSION); } catch (e) {}
    setStudent(null);
    setAnswers({});
    setEssayText('');
    setIsSubmissionModalOpen(false);
    setActiveTab('comprehension');
  };

  // Calculate Georgian/Unicode word count
  const calculateWordCount = (text: string): number => {
    const trimmed = text.trim();
    if (!trimmed) return 0;
    return trimmed.split(/\s+/).filter(word => word.length > 0).length;
  };

  const essayWordCount = calculateWordCount(essayText);
  const answeredCount = Object.keys(answers).length;

  // ტესტების სია ან ტესტი ვერ ჩაიტვირთა
  if (loadError) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 via-indigo-50/20 to-slate-100 flex items-center justify-center p-4 md:p-6">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-200/80 p-6 md:p-8 text-center">
          <div className="text-sm font-bold text-slate-800 mb-1">ტესტები ვერ ჩაიტვირთა</div>
          <p className="text-xs text-slate-500">{loadError}</p>
        </div>
      </div>
    );
  }

  // If student hasn't entered name yet
  if (!student) {
    return (
      <>
        <StartScreen
          onStartExam={(s) => setStudent(s)}
          tests={tests}
          selectedTestId={selectedTestId}
          onSelectTest={setSelectedTestId}
        />
        <TeacherConfigModal
          isOpen={isTeacherConfigOpen}
          onClose={() => setIsTeacherConfigOpen(false)}
          webhookUrl={webhookUrl}
          onSaveWebhookUrl={handleSaveWebhookUrl}
          teacherEmail={teacherEmail}
          onSaveTeacherEmail={handleSaveTeacherEmail}
        />
      </>
    );
  }

  if (!exam) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 via-indigo-50/20 to-slate-100 flex items-center justify-center p-4 md:p-6">
        <div className="text-sm font-semibold text-slate-500">ტექსტი იტვირთება…</div>
      </div>
    );
  }

  return (
    <ExamProvider test={exam}>
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Sticky Top Header */}
      <StudentHeader
        student={student}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        answeredCount={answeredCount}
        essayWordCount={essayWordCount}
        onSubmitClick={() => setIsSubmissionModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto w-full px-3 sm:px-6 py-6 flex-1">
        {activeTab === 'comprehension' && (
          <ComprehensionSection
            answers={answers}
            onSelectAnswer={handleSelectAnswer}
            onOpenPoem={() => setIsPoemModalOpen(true)}
            onGoToEssay={() => setActiveTab('essay')}
          />
        )}

        {activeTab === 'essay' && (
          <EssaySection
            essayText={essayText}
            onEssayChange={setEssayText}
            wordCount={essayWordCount}
            onOpenPoem={() => setIsPoemModalOpen(true)}
          />
        )}
      </main>

      {/* Sticky Bottom Bar on Mobile for quick submit / poem view */}
      <div className="md:hidden sticky bottom-0 z-20 bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 flex items-center justify-between gap-2 shadow-lg">
        <button
          onClick={() => setIsPoemModalOpen(true)}
          className="flex-1 py-2 px-3 bg-amber-50 text-amber-900 border border-amber-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5"
        >
          📖 ტექსტი
        </button>
        <button
          onClick={() => setIsSubmissionModalOpen(true)}
          className="flex-1 py-2 px-3 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5"
        >
          ✓ გაგზავნა
        </button>
      </div>

      {/* Modals */}
      <PoemModal
        isOpen={isPoemModalOpen}
        onClose={() => setIsPoemModalOpen(false)}
      />

      <SubmissionModal
        isOpen={isSubmissionModalOpen}
        onClose={() => setIsSubmissionModalOpen(false)}
        student={student}
        answers={answers}
        essayText={essayText}
        essayWordCount={essayWordCount}
        webhookUrl={webhookUrl}
        teacherEmail={teacherEmail}
        startedAt={startedAt}
        onResetExam={handleResetExam}
      />

      <TeacherConfigModal
        isOpen={isTeacherConfigOpen}
        onClose={() => setIsTeacherConfigOpen(false)}
        webhookUrl={webhookUrl}
        onSaveWebhookUrl={handleSaveWebhookUrl}
        teacherEmail={teacherEmail}
        onSaveTeacherEmail={handleSaveTeacherEmail}
      />
    </div>
    </ExamProvider>
  );
}
