import React, { useState, useEffect } from 'react';
import { StudentInfo, ExamTest, TestSummary } from './types';
import { SITE_CONFIG } from './config';
import { ExamProvider, loadTestIndex, loadTest, loadSiteConfig } from './data/examSource';
import { StartScreen } from './components/StartScreen';
import { StudentHeader } from './components/StudentHeader';
import { ComprehensionSection } from './components/ComprehensionSection';
import { EssaySection } from './components/EssaySection';
import { PoemViewer } from './components/PoemViewer';
import { PoemModal } from './components/PoemModal';
import { SubmissionModal } from './components/SubmissionModal';
import { TeacherConfigModal } from './components/TeacherConfigModal';

const STORAGE_KEYS = {
  STUDENT: 'georgian_exam_student',
  ANSWERS: 'georgian_exam_answers',
  ESSAY: 'georgian_exam_essay',
  WEBHOOK: 'georgian_exam_webhook_url',
  TEACHER_EMAIL: 'georgian_exam_teacher_email',
  TEST: 'georgian_exam_test_id',
};

// პასუხები და თხზულება ცალკე ინახება თითოეული ტექსტისთვის
const answersKey = (testId: string) => `${STORAGE_KEYS.ANSWERS}:${testId}`;
const essayKey = (testId: string) => `${STORAGE_KEYS.ESSAY}:${testId}`;

export default function App() {
  const [student, setStudent] = useState<StudentInfo | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.STUDENT);
    return saved ? JSON.parse(saved) : null;
  });

  const [tests, setTests] = useState<TestSummary[]>([]);
  const [selectedTestId, setSelectedTestId] = useState<string>(
    () => localStorage.getItem(STORAGE_KEYS.TEST) || ''
  );
  const [exam, setExam] = useState<ExamTest | null>(null);
  const [loadError, setLoadError] = useState<string>('');

  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [essayText, setEssayText] = useState<string>('');

  // config.ts-ის მისამართი ყველა მოსწავლესთან მოქმედებს;
  // ლოკალური პარამეტრი მხოლოდ შემოწმებისთვისაა
  const [webhookUrl, setWebhookUrl] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.WEBHOOK) || SITE_CONFIG.webhookUrl;
  });

  const [teacherEmail, setTeacherEmail] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEYS.TEACHER_EMAIL) || SITE_CONFIG.teacherEmail;
  });

  const [activeTab, setActiveTab] = useState<'all' | 'comprehension' | 'essay'>('all');
  const [isPoemModalOpen, setIsPoemModalOpen] = useState(false);
  const [isSubmissionModalOpen, setIsSubmissionModalOpen] = useState(false);
  const [isTeacherConfigOpen, setIsTeacherConfigOpen] = useState(false);

  // საიტის პარამეტრები — config.json-ის რედაქტირება GitHub-ზე მაშინვე მოქმედებს
  useEffect(() => {
    loadSiteConfig().then(cfg => {
      if (cfg.webhookUrl && !localStorage.getItem(STORAGE_KEYS.WEBHOOK)) {
        setWebhookUrl(cfg.webhookUrl);
      }
      if (cfg.teacherEmail && !localStorage.getItem(STORAGE_KEYS.TEACHER_EMAIL)) {
        setTeacherEmail(cfg.teacherEmail);
      }
    });
  }, []);

  // ტესტების სიის ჩატვირთვა
  useEffect(() => {
    loadTestIndex()
      .then(list => {
        setTests(list);
        setSelectedTestId(prev =>
          prev && list.some(t => t.id === prev) ? prev : (list[0]?.id ?? '')
        );
      })
      .catch(err => setLoadError(err.message));
  }, []);

  // არჩეული ტესტის ჩატვირთვა + მისი შენახული პასუხების აღდგენა
  useEffect(() => {
    const summary = tests.find(t => t.id === selectedTestId);
    if (!summary) {
      setExam(null);
      return;
    }
    localStorage.setItem(STORAGE_KEYS.TEST, summary.id);
    let cancelled = false;
    loadTest(summary)
      .then(t => {
        if (cancelled) return;
        setExam(t);
        const savedAnswers = localStorage.getItem(answersKey(t.id));
        const savedEssay = localStorage.getItem(essayKey(t.id));
        setAnswers(savedAnswers ? JSON.parse(savedAnswers) : {});
        setEssayText(savedEssay || '');
      })
      .catch(err => !cancelled && setLoadError(err.message));
    return () => {
      cancelled = true;
    };
  }, [selectedTestId, tests]);

  // Sync state to LocalStorage
  useEffect(() => {
    if (student) {
      localStorage.setItem(STORAGE_KEYS.STUDENT, JSON.stringify(student));
    } else {
      localStorage.removeItem(STORAGE_KEYS.STUDENT);
    }
  }, [student]);

  useEffect(() => {
    if (exam) localStorage.setItem(answersKey(exam.id), JSON.stringify(answers));
  }, [answers, exam]);

  useEffect(() => {
    if (exam) localStorage.setItem(essayKey(exam.id), essayText);
  }, [essayText, exam]);

  const handleSaveWebhookUrl = (url: string) => {
    setWebhookUrl(url);
    localStorage.setItem(STORAGE_KEYS.WEBHOOK, url);
  };

  const handleSaveTeacherEmail = (email: string) => {
    setTeacherEmail(email);
    localStorage.setItem(STORAGE_KEYS.TEACHER_EMAIL, email);
  };

  const handleSelectAnswer = (questionId: number, optionKey: 'ა' | 'ბ' | 'გ' | 'დ') => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: optionKey,
    }));
  };

  const handleResetExam = () => {
    localStorage.removeItem(STORAGE_KEYS.STUDENT);
    if (exam) {
      localStorage.removeItem(answersKey(exam.id));
      localStorage.removeItem(essayKey(exam.id));
    }
    setStudent(null);
    setAnswers({});
    setEssayText('');
    setIsSubmissionModalOpen(false);
    setActiveTab('all');
  };

  // Calculate Georgian/Unicode word count
  const calculateWordCount = (text: string): number => {
    const trimmed = text.trim();
    if (!trimmed) return 0;
    return trimmed.split(/\s+/).filter(word => word.length > 0).length;
  };

  const essayWordCount = calculateWordCount(essayText);
  const answeredCount = Object.keys(answers).length;

  // ტესტების სია ან ტესტი ვერ ჩაიტვირთა
  if (loadError) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 via-indigo-50/20 to-slate-100 flex items-center justify-center p-4 md:p-6">
        <div className="w-full max-w-md bg-white rounded-3xl shadow-xl border border-slate-200/80 p-6 md:p-8 text-center">
          <div className="text-sm font-bold text-slate-800 mb-1">ტესტები ვერ ჩაიტვირთა</div>
          <p className="text-xs text-slate-500">{loadError}</p>
        </div>
      </div>
    );
  }

  // If student hasn't entered name yet
  if (!student) {
    return (
      <>
        <StartScreen
          onStartExam={(s) => setStudent(s)}
          onOpenTeacherGuide={() => setIsTeacherConfigOpen(true)}
          tests={tests}
          selectedTestId={selectedTestId}
          onSelectTest={setSelectedTestId}
        />
        <TeacherConfigModal
          isOpen={isTeacherConfigOpen}
          onClose={() => setIsTeacherConfigOpen(false)}
          webhookUrl={webhookUrl}
          onSaveWebhookUrl={handleSaveWebhookUrl}
          teacherEmail={teacherEmail}
          onSaveTeacherEmail={handleSaveTeacherEmail}
        />
      </>
    );
  }

  if (!exam) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 via-indigo-50/20 to-slate-100 flex items-center justify-center p-4 md:p-6">
        <div className="text-sm font-semibold text-slate-500">ტექსტი იტვირთება…</div>
      </div>
    );
  }

  return (
    <ExamProvider test={exam}>
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Sticky Top Header */}
      <StudentHeader
        student={student}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        answeredCount={answeredCount}
        essayWordCount={essayWordCount}
        onOpenPoemModal={() => setIsPoemModalOpen(true)}
        onSubmitClick={() => setIsSubmissionModalOpen(true)}
        onOpenTeacherConfig={() => setIsTeacherConfigOpen(true)}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto w-full px-3 sm:px-6 py-6 flex-1">
        {activeTab === 'all' && (
          <div className="space-y-10">
            {/* Component 1: Comprehension */}
            <section id="comprehension-section">
              <ComprehensionSection
                answers={answers}
                onSelectAnswer={handleSelectAnswer}
                onOpenPoem={() => setIsPoemModalOpen(true)}
                onGoToEssay={() => {
                  const el = document.getElementById('essay-section');
                  if (el) {
                    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
                  }
                }}
              />
            </section>

            {/* Visual Divider */}
            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-slate-300"></div>
              <span className="shrink mx-4 text-xs font-bold text-slate-500 uppercase tracking-wider bg-slate-200/80 px-3 py-1 rounded-full">
                კომპონენტი II • თხზულება (დავალება 12)
              </span>
              <div className="flex-grow border-t border-slate-300"></div>
            </div>

            {/* Component 2: Essay */}
            <section id="essay-section">
              <EssaySection
                essayText={essayText}
                onEssayChange={setEssayText}
                wordCount={essayWordCount}
              />
            </section>
          </div>
        )}

        {activeTab === 'comprehension' && (
          <ComprehensionSection
            answers={answers}
            onSelectAnswer={handleSelectAnswer}
            onOpenPoem={() => setIsPoemModalOpen(true)}
            onGoToEssay={() => setActiveTab('essay')}
          />
        )}

        {activeTab === 'essay' && (
          <EssaySection
            essayText={essayText}
            onEssayChange={setEssayText}
            wordCount={essayWordCount}
          />
        )}
      </main>

      {/* Sticky Bottom Bar on Mobile for quick submit / poem view */}
      <div className="md:hidden sticky bottom-0 z-20 bg-white/95 backdrop-blur-md border-t border-slate-200 p-3 flex items-center justify-between gap-2 shadow-lg">
        <button
          onClick={() => setIsPoemModalOpen(true)}
          className="flex-1 py-2 px-3 bg-amber-50 text-amber-900 border border-amber-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5"
        >
          📖 ტექსტი
        </button>
        <button
          onClick={() => setIsSubmissionModalOpen(true)}
          className="flex-1 py-2 px-3 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs flex items-center justify-center gap-1.5"
        >
          ✓ გაგზავნა
        </button>
      </div>

      {/* Modals */}
      <PoemModal
        isOpen={isPoemModalOpen}
        onClose={() => setIsPoemModalOpen(false)}
      />

      <SubmissionModal
        isOpen={isSubmissionModalOpen}
        onClose={() => setIsSubmissionModalOpen(false)}
        student={student}
        answers={answers}
        essayText={essayText}
        essayWordCount={essayWordCount}
        webhookUrl={webhookUrl}
        teacherEmail={teacherEmail}
        onResetExam={handleResetExam}
      />

      <TeacherConfigModal
        isOpen={isTeacherConfigOpen}
        onClose={() => setIsTeacherConfigOpen(false)}
        webhookUrl={webhookUrl}
        onSaveWebhookUrl={handleSaveWebhookUrl}
        teacherEmail={teacherEmail}
        onSaveTeacherEmail={handleSaveTeacherEmail}
      />
    </div>
    </ExamProvider>
  );
}
